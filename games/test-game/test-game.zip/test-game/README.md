# Game Template

The starting point for a game of your own. It plays a plain game (every playfield switch scores 1000) so you can check that the machine
works, then you change it into your game.

1. Copy this folder, for example to my-game, and edit game.json: the id (letters, digits and dashes), the name and the start script name.
   Rename start-my-game.sh to match what start_script says.
2. Put the folder in /opt/pinball (next to p2k-bridge and p2k-panel) with: bash /opt/pinball/p2k-panel/install-game.sh /path/to/my-game
3. Open the panel (http://<the PC>:8095/), pick the game on the Overview page and press Start.
4. Change the rules in modes/base/config/base.yaml and add modes under modes/ (list them in config/config.yaml).

Keep the hardware sections of config/config.yaml as they are. The helper modes are kept: tilt, switch_health (dead switch report), quit_combo
(hold both flippers and both action buttons for 5 seconds in attract mode to quit), reset_game (hold Start for 3 seconds) and status_page
(hold Launch to bring the panel to the front).

Screens, sound and music are up to you. The panel can also edit screens that follow the display layout of plugins/display in p2k-panel: list "display" in "features" in
game.json and put the display folder in the game. See ../guides/making-a-game.md.

## Moving target (modes/sweep)

A bullseye target glides back and forth across the glass for 40 seconds. Hit the centre targets as it passes over the middle spot: a bullseye pays 50,000, close pays 25,000, a hit with the target elsewhere pays nothing, and every hit makes it quicker. The glass page judges each hit (it knows where the target is) and sends dj_sweep_perfect, dj_sweep_good or dj_sweep_miss, which modes/sweep scores. Press M on the glass during a game to start it (base.yaml turns the dj_sweep_go event into sweep_go), or post sweep_go yourself. Outside a game, M runs a local test: Space on each pass shows how early or late you were and Enter keeps the average as the delay. The numbers, the spots that count and the look (target or record) are under `sweep` in display/display.json. To drop it from your game: delete modes/sweep, the `sweep` line in config/config.yaml, the event_player lines in base.yaml, and the sweep code in display/game.js and display/style.css.

## Targets (modes/targets)

One static bullseye target at a time shows on one of the five spots (display.json, record_slots), for 45 seconds. It grows for 3 seconds (the target coming up), turns green for 2 seconds (in the groove), then goes, and the next comes up a second later on a different spot. Hit the shot under it for 25,000, or 50,000 while it is green. The five spots are the left ramp exit, martian target 4, the four centre targets, the centre loop and the drop target (raised for you when the target is on spot 5): see the shots at the top of modes/targets/config/targets.yaml. Press T on the glass during a game to start it (base.yaml turns dj_targets_go into targets_go), or post targets_go yourself. Outside a game, N runs the same timeline in the page with no playfield: keys 1 to 5 are the shots and the score shows at the end. Starting it ends the moving target and the other way round. To drop it from your game: delete modes/targets, its line in config/config.yaml, the dj_targets_go line in base.yaml and the targets code in display/game.js and display/style.css.

## Random target (modes/random_target)

A surprise in normal play. Every 10 seconds of plain play the dice have a 1 in 12 chance (about once every 2 minutes) of starting something: the random target (the drop target comes up, a bullseye shows on spot 5 with a 30 second clock, and knocking the drop target down in time pays 100,000), the moving target, or the target mode. The dice wait while any of those is running, and start only after a full 10 seconds (the first tick when the timer starts is ignored). The chance, how often they are thrown, what they can start, the clock and the reward are on the Targets tab of the panel (Game logic group), or by hand in the mode file; "int: 0" under rt_dice turns the dice off.

## Settings, picture and path (Targets tab)

The panel's Targets tab (Display group) sets the moving target and the target mode without editing files: times, speed, scores, size, which spots count, a picture to use instead of the bullseye (upload it there), and the path the moving target takes: click to add points, drag to move them, arrow keys nudge a picked point, Draw freehand with the mouse, or use Circle, Figure eight, Zigzag, Wave. Save writes display/display.json (`sweep` with `path`, `unit_px`, `size`, `image`; `targets` with `size`, `image`) and the numbers in the mode files; reload the glass to see it, restart the game software for new times and scores.
