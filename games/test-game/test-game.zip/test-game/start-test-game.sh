#!/bin/bash
# start-game-template.sh: run the game. p2kd must already be running (it is a service) unless the game's hardware is set to Other MPF hardware or Simulated on the panel's System tab. Ctrl+C or quitting MPF ends it.
#
# The panel (p2k-panel) starts this script from its Start button and finds out which monitor is the backglass from the
# BACKGLASS_SCREEN line below (it is used when the original game is started through Pinbox; leave it empty when there is no backglass monitor).
# Use the monitor's name as shown by xrandr (HDMI-1, DP-2), or a number (1 is the first monitor listed).

BACKGLASS_SCREEN=2          # the backglass monitor (display/backglass.html goes on it; also used when the original game is started through Pinbox). Empty means no backglass.

# Which monitor the glass page (display/index.html, the Pepper's ghost screen) goes on: the monitor's name as xrandr shows it
# (HDMI-1, VGA-1), "primary", or a number (1 is the first monitor listed). Leave it empty to run without the glass page.
MAIN_SCREEN=1

# ---------------------------------------------------------------------------
GAME=$(cd "$(dirname "$0")" && pwd)
BRIDGE=${BRIDGE:-$(cd "$GAME/.." && pwd)/p2k-bridge}
[ -f ~/mpf/bin/activate ] && source ~/mpf/bin/activate
export PYTHONPATH=$BRIDGE
export DISPLAY=${DISPLAY:-:0}
cd "$GAME"

pids=()
cleanup() { kill "${pids[@]}" 2>/dev/null; pkill -f -- "--user-data-dir=.*$GAME/.browser-" 2>/dev/null; }
trap cleanup EXIT INT TERM

# the panel's cabinet buttons hold the driver board while no game runs: ask it to let go (p2kd takes one program at a time)
curl -s -m 2 -X POST -d '{"seconds":120}' http://localhost:8095/api/nav/pause >/dev/null 2>&1 && sleep 1

# The glass page: the display server (port 8090) serves the display folder and passes MPF's events to the page, and a browser
# shows it full screen on the glass monitor. Skipped when there is no display folder, no MAIN_SCREEN, no X desktop or no browser.
BROWSER=$(command -v chromium || command -v chromium-browser || command -v google-chrome)
# find_screen NAME-OR-NUMBER prints "X,Y WIDTH,HEIGHT" for a connected monitor (by name, number or "primary")
find_screen() {
  local want=$1 n=0 name w h x y prim
  while read -r name w h x y prim; do
    n=$((n + 1))
    if [ "$name" = "$want" ] || [ "$n" = "$want" ] || { [ "$want" = primary ] && [ "$prim" = primary ]; }; then echo "$x,$y $w,$h"; return 0; fi
  done < <(xrandr --query 2>/dev/null | awk '/ connected/ { for (i = 3; i <= NF; i++) if (match($i, /^[0-9]+x[0-9]+\+[0-9]+\+[0-9]+$/)) { split($i, a, /[x+]/); print $1, a[1], a[2], a[3], a[4], ($3 == "primary" ? "primary" : "-"); break } }')
  return 1
}
kiosk() {   # kiosk URL "X,Y W,H" NAME
  local pos size; read -r pos size <<< "$2"
  mkdir -p "$GAME/.browser-$3"
  "$BROWSER" --kiosk --app="$1" --window-position="$pos" --window-size="$size" --user-data-dir="$GAME/.browser-$3" \
    --no-first-run --noerrdialogs --disable-infobars --autoplay-policy=no-user-gesture-required >/dev/null 2>&1 &
  pids+=($!)
}
if [ -n "$MAIN_SCREEN" ] && [ -f "$GAME/display/index.html" ] && [ -n "$BROWSER" ] && command -v xrandr >/dev/null; then
  if MAIN=$(find_screen "$MAIN_SCREEN"); then
    python3 "$BRIDGE/display/p2kdisplay.py" --display "$GAME/display" &
    pids+=($!)
    sleep 1
    kiosk http://localhost:8090/ "$MAIN" glass
    # the backglass page, when there is a backglass monitor and the game has display/backglass.html
    if [ -n "$BACKGLASS_SCREEN" ] && [ -f "$GAME/display/backglass.html" ] && BACK=$(find_screen "$BACKGLASS_SCREEN") && [ "$BACK" != "$MAIN" ]; then
      kiosk http://localhost:8090/backglass.html "$BACK" backglass
    fi
  else
    echo "Monitor '$MAIN_SCREEN' not found (xrandr --query lists them), starting without the glass page."
  fi
fi

# With no terminal (started from the panel, or by a service) MPF's text screen cannot open and MPF stops at once, so it is switched off (-t) then.
MPF_ARGS=()
[ -t 1 ] || MPF_ARGS+=(-t)
# The panel sets P2K_HARDWARE from the game's hardware setting (System tab, Games): p2kd (default), mpf (other hardware, p2kd not used, set up in config/config.yaml) or virtual (MPF's simulated hardware).
[ "$P2K_HARDWARE" = virtual ] && MPF_ARGS+=(-X)
mpf game "${MPF_ARGS[@]}"
