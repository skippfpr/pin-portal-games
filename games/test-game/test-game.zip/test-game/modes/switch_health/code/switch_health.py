"""Dead switch detection. See modes/switch_health/config/switch_health.yaml."""

import json
import os
import time

from mpf.core.file_manager import FileManager
from mpf.core.mode import Mode


class SwitchHealth(Mode):

    def mode_init(self):
        s = self.config.get('mode_settings', {}) or {}
        self._tags = [t.strip() for t in str(s.get('monitor_tags', 'points')).split(',') if t.strip()]
        self._dead_after = int(s.get('dead_after_games', 5))
        self._min_hits = int(s.get('min_game_hits', 25))
        self._stuck_ms = int(float(s.get('stuck_seconds', 30)) * 1000)
        self._ignore = set(self._as_list(s.get('ignore')))
        self._slow = {k: int(v) for k, v in (s.get('slow') or {}).items()}
        self._report_events = self._as_list(s.get('report_events'))
        self._file = os.path.join(self.machine.machine_path, 'data', 'switch_health.yaml')
        self._data = {}          # name -> {hits, games_missed, last_hit, status}
        self._run_hits = {}      # hits since the last game ended
        self._stuck = set()
        self._watching = []
        self._load()

    @staticmethod
    def _as_list(v):
        if not v:
            return []
        if isinstance(v, str):
            return [x.strip() for x in v.split(',') if x.strip()]
        return list(v)

    # ------------------------------------------------------------ storage
    def _load(self):
        try:
            if os.path.isfile(self._file):
                raw = FileManager.load(self._file, halt_on_error=False) or {}
                self._data = {k: dict(v) for k, v in (raw.get('switches') or {}).items()}
        except Exception as e:      # a damaged file must never stop the game
            self.warning_log("switch_health: could not read %s (%s), starting again", self._file, e)
            self._data = {}

    def _save(self):
        # MPF's own YAML writer is shared by every file it saves, and the data manager writes the
        # audits from another thread, so using it here at game end could collide with that write and
        # fail on both files. JSON is valid YAML, so this file keeps its name and _load still reads it.
        try:
            os.makedirs(os.path.dirname(self._file), exist_ok=True)
            tmp = self._file + '.tmp'
            with open(tmp, 'w', encoding='utf8') as f:
                json.dump({'switches': self._data}, f, indent=1, sort_keys=True)
            os.replace(tmp, self._file)
        except Exception as e:
            self.warning_log("switch_health: could not write %s (%s)", self._file, e)

    def _entry(self, name):
        e = self._data.setdefault(name, {})
        e.setdefault('hits', 0)
        e.setdefault('games_missed', 0)
        e.setdefault('last_hit', 'never')
        e.setdefault('status', 'ok')
        return e

    # ------------------------------------------------------------ watching
    def mode_start(self, **kwargs):
        names = set()
        for tag in self._tags:
            for sw in self.machine.switches.items_tagged(tag):
                if sw.name not in self._ignore:
                    names.add(sw.name)
        self._names = sorted(names)
        for name in self._names:
            self._entry(name)
            sc = self.machine.switch_controller
            sc.add_switch_handler(name, self._hit, state=1, callback_kwargs={'name': name})
            sc.add_switch_handler(name, self._stuck_check, state=1, ms=self._stuck_ms, callback_kwargs={'name': name})
            sc.add_switch_handler(name, self._released, state=0, callback_kwargs={'name': name})
        for ev in self._report_events:
            self.add_mode_event_handler(ev, self._report_event)
        self.add_mode_event_handler('game_ended', self._game_ended)
        self.info_log("switch_health: watching %s switches", len(self._names))
        self._report()

    def _hit(self, name, **kwargs):
        e = self._entry(name)
        e['hits'] += 1
        e['games_missed'] = 0
        e['last_hit'] = time.strftime('%Y-%m-%d %H:%M')
        self._run_hits[name] = self._run_hits.get(name, 0) + 1
        if e['status'] == 'dead':
            e['status'] = 'ok'
            self.info_log("switch_health: %s is working again", name)
            self.machine.events.post('switch_health_recovered', switch=name)
            self._save()
            self._report()

    def _stuck_check(self, name, **kwargs):
        if not self.machine.game or name in self._stuck:
            return
        self._stuck.add(name)
        self.warning_log("switch_health: %s has been closed for %s seconds, it may be stuck",
                         name, self._stuck_ms // 1000)
        self.machine.events.post('switch_health_stuck', switch=name)
        self._report()

    def _released(self, name, **kwargs):
        if name in self._stuck:
            self._stuck.discard(name)
            self._report()

    # ------------------------------------------------------------ games
    def _game_ended(self, **kwargs):
        total = sum(self._run_hits.values())
        if total >= self._min_hits:
            for name in self._names:
                e = self._entry(name)
                if not self._run_hits.get(name):
                    e['games_missed'] += 1
                if e['games_missed'] >= self._dead_after * self._slow.get(name, 1):
                    if e['status'] != 'dead':
                        self.warning_log("switch_health: %s not hit for %s games, it may be dead",
                                         name, e['games_missed'])
                    e['status'] = 'dead'
        else:
            self.debug_log("switch_health: only %s hits that game, not counted", total)
        self._run_hits = {}
        self._save()
        self._report()

    # ------------------------------------------------------------ reporting
    def dead(self):
        return [n for n in self._names if self._entry(n)['status'] == 'dead']

    def _report_event(self, **kwargs):
        self._report()

    def _report(self):
        dead, stuck = self.dead(), sorted(self._stuck)
        self.machine.events.post('switch_health_report', dead=','.join(dead), stuck=','.join(stuck),
                                 count=len(dead) + len(stuck))
        if dead:
            self.warning_log("switch_health: possibly dead switches: %s", ', '.join(dead))
