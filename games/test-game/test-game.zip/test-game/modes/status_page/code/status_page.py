"""Hold the launch button in attract mode to bring the status page to the front. See status_page.yaml."""

import threading
import urllib.request

from mpf.core.mode import Mode


class StatusPage(Mode):

    def mode_init(self):
        s = self.config.get('mode_settings', {}) or {}
        self._switch = str(s.get('switch', 's_launch')).strip()
        self._hold = float(s.get('hold_seconds', 5))
        self._url = str(s.get('url', 'http://localhost:8095/api/window/show')).strip()
        self._holding = False
        self._armed = False

    def mode_start(self, **kwargs):
        sc = self.machine.switch_controller
        sc.add_switch_handler(self._switch, self._check)
        sc.add_switch_handler(self._switch, self._check, state=0)
        # a button that is already down when attract starts (the end of a game) has to be let go first
        self._armed = not self._down()
        self._holding = False

    def mode_stop(self, **kwargs):       # a game has started: never from here
        sc = self.machine.switch_controller
        sc.remove_switch_handler(self._switch, self._check)
        sc.remove_switch_handler(self._switch, self._check, state=0)
        self.delay.clear()
        self._holding = False

    def _down(self):
        return self.machine.switches[self._switch].state == 1

    def _check(self, **kwargs):
        if not self.active:
            return
        if not self._down():
            self._armed = True
            if self._holding:
                self._holding = False
                self.delay.remove('show')
            return
        if self._armed and not self._holding:
            self._holding = True
            self.delay.add(int(self._hold * 1000), self._show, 'show')

    def _show(self, **kwargs):
        self._holding = False
        if not self.active or not self._down():
            return
        self._armed = False              # let go before it can happen again
        self.warning_log("status_page: %s held for %s seconds, showing the status page", self._switch, self._hold)
        self.machine.events.post('status_page_show')
        threading.Thread(target=self._call, daemon=True).start()

    def _call(self):
        try:
            req = urllib.request.Request(self._url, data=b'{}', method='POST')
            urllib.request.urlopen(req, timeout=3).read()
        except Exception as e:           # the status site may not be running: the game carries on regardless
            self.warning_log("status_page: could not reach %s (%s)", self._url, e)
