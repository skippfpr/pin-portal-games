"""Hold the start button for a few seconds during a game to reset it. See reset_game.yaml."""

from mpf.core.mode import Mode


class ResetGame(Mode):

    def mode_init(self):
        s = self.config.get('mode_settings', {}) or {}
        self._name = str(s.get('switch', 's_start'))
        self._hold = float(s.get('hold_seconds', 3))
        self._holding = False

    def mode_start(self, **kwargs):
        sc = self.machine.switch_controller
        sc.add_switch_handler(self._name, self._check)
        sc.add_switch_handler(self._name, self._check, state=0)
        self._check()

    def mode_stop(self, **kwargs):
        sc = self.machine.switch_controller
        sc.remove_switch_handler(self._name, self._check)
        sc.remove_switch_handler(self._name, self._check, state=0)
        self.delay.clear()
        if self._holding:
            self._holding = False
            self.machine.events.post('reset_hold_cancel')

    def _down(self):
        return self.machine.switches[self._name].state == 1

    def _check(self, **kwargs):
        if not self.active:
            return
        down = self._down()
        if down and not self._holding:
            self._holding = True
            self.machine.events.post('reset_hold_start', seconds=int(self._hold))
            self.delay.add(int(self._hold * 1000), self._reset, 'reset')
        elif not down and self._holding:
            self._holding = False
            self.delay.remove('reset')
            self.machine.events.post('reset_hold_cancel')

    def _reset(self, **kwargs):
        if not self.active or not self._down() or not self.machine.game:
            return
        self.warning_log("reset_game: start held for %s seconds, ending the game", self._hold)
        self._holding = False
        self.machine.events.post('reset_now')
        # nothing from a reset game goes on the high score table
        for player in list(self.machine.game.player_list):
            player.score = 0
        self.machine.events.post('end_game')
