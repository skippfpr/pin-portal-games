"""Hold all the buttons for a few seconds in attract mode to quit. See quit_combo.yaml."""

from mpf.core.mode import Mode


class QuitCombo(Mode):

    def mode_init(self):
        s = self.config.get('mode_settings', {}) or {}
        sw = s.get('switches', '')
        self._names = [x.strip() for x in (sw.split(',') if isinstance(sw, str) else sw) if x.strip()]
        self._hold = float(s.get('hold_seconds', 5))
        self._holding = False

    def mode_start(self, **kwargs):
        sc = self.machine.switch_controller
        for n in self._names:
            sc.add_switch_handler(n, self._check)
            sc.add_switch_handler(n, self._check, state=0)
        self._check()

    def mode_stop(self, **kwargs):       # a game has started (or attract is over): never quit from here
        sc = self.machine.switch_controller
        for n in self._names:
            sc.remove_switch_handler(n, self._check)
            sc.remove_switch_handler(n, self._check, state=0)
        self.delay.clear()
        if self._holding:
            self._holding = False
            self.machine.events.post('quit_hold_cancel')

    def _all_down(self):
        return bool(self._names) and all(self.machine.switches[n].state == 1 for n in self._names)

    def _check(self, **kwargs):
        if not self.active:
            return
        down = self._all_down()
        if down and not self._holding:
            self._holding = True
            self.machine.events.post('quit_hold_start', seconds=int(self._hold))
            self.delay.add(int(self._hold * 1000), self._quit, 'quit')
        elif not down and self._holding:
            self._holding = False
            self.delay.remove('quit')
            self.machine.events.post('quit_hold_cancel')

    def _quit(self, **kwargs):
        if not self.active or not self._all_down():
            return
        self.warning_log("quit_combo: buttons held for %s seconds, shutting down", self._hold)
        self.machine.events.post('quit_now')
        self.delay.add(800, lambda: self.machine.stop('quit combo'), 'stop')
