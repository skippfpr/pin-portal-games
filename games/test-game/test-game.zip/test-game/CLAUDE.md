# Notes for Claude: this game

This is a game for a Pinball 2000 cabinet, made from the builder kit's game-template. The kit's CLAUDE.md (in the folder above the games, next to p2k-panel) has the full rules for helping with it; read that first if it is there. In short:

Keep the hardware sections of config/config.yaml as they are. Put the rules in modes/, each assumption as one number at the top of its file, and list them in RULES.md in plain words. Test with the hardware platform changed to smart_virtual before anything goes on the machine, and say clearly what has only been simulated. Never hold a coil on or raise a pulse. Install changes with bash p2k-panel/install-game.sh this-folder --update.

Ask the person what the game should feel like before writing rules, three questions at most at a time.
