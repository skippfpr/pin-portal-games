// edit.js: the layout editor mode of both screens (?edit=1). Loaded by core.js only in edit mode, never on the cabinet.
//
// The Layout tab of the status site shows the real page in a frame. This file draws a box over every piece of the page,
// lets you drag it (move) or pull its corner (size), and tells the tab what changed. It takes no game events and
// sends nothing to MPF. A "scene" fills the page with sample content so that a screen that only shows for a moment
// in a game (the music picker, the initials, game over) can be laid out in peace.
//
// Messages with the parent page (the Layout tab):
//   page to tab:  {fdj:'ready', page, scenes}   {fdj:'layout', page, layout}   {fdj:'select', id, vals}
//   tab to page:  {fdj:'scene', name}  {fdj:'set', layout}  {fdj:'select', id}  {fdj:'key', key, shift}  {fdj:'reset', id}  {fdj:'grid', on}  {fdj:'snap', on}
// A layout is {id: {x, y, s}}: x and y in pixels of the glass stage, or percent of the backglass width and height; s is the size.
P2K.editor = (page, saved, savedExtras, savedFonts, savedPages) => {
  const $ = id => document.getElementById(id);
  const body = document.body;
  const glass = page === 'glass';
  const U = glass ? { x: 'px', y: 'px' } : { x: '%', y: '%' };
  let layout = JSON.parse(JSON.stringify(saved || {})), extras = JSON.parse(JSON.stringify(savedExtras || [])), fontFiles = savedFonts || [], pages = JSON.parse(JSON.stringify(savedPages || []));
  const apply = () => P2K.setLayout(layout, extras, fontFiles, pages);
  let guides = [], snapOn = true;                                  // snap lines while dragging (the Layout tab's checkbox; hold Alt to move freely)
  let group = [], mq = null;                                       // the pieces picked together (drag a box on empty space, or Shift-click); sel is the main one
  let sel = null, scene = null, showGrid = false, showParts = false;
  const partSel = id => { const a = id.split('>'); return '#' + a[0] + a.slice(1).map(n => '>:nth-child(' + n + ')').join(''); };
  const elOf = id => { try { return document.querySelector(partSel(id)); } catch (e) { return null; } };

  // ---------------------------------------------------------------- the scenes
  const feed = o => P2K.receive(Object.assign({ cmd: 'state', mpf_connected: true, in_game: false, player: null, players: {}, modes: [], vars: {}, best: [], genre_best: {}, last_game: [] }, o));
  const SAMPLE_BEST = [{ name: 'DJX', score: 8450000 }, { name: 'MIX', score: 6120000 }, { name: 'SKP', score: 4980000 }, { name: 'AAA', score: 2310000 }, { name: 'ZZZ', score: 990000 }];
  const SAMPLE_GENRE = { house: { name: 'DJX', score: 3300000 }, techno: { name: 'SKP', score: 2100000 }, any: { name: 'MIX', score: 1800000 } };
  const GAME = o => feed(Object.assign({ in_game: true, player: 1, players: { 1: 2456000, 2: 1130000 },
    vars: { 1: { ball: 2, lock_shots: 2, top_mult: 3, boss_max: 10, boss_hp: 7, spin_orbits: 3, mix_mult: 3, lock_lit: 0, dj_balls: 1 } } }, o));
  const E = (id, label) => ({ id, label });
  const text = (id, s) => { const e = $(id); if (e) e.textContent = s; };

  const GLASS = {
    attract: { label: 'Attract (waiting for a game)', els: [E('title', 'Title or logo'), E('best', 'High scores'), E('attract-line', 'Message line')],
      enter() { feed({ best: SAMPLE_BEST, genre_best: SAMPLE_GENRE }); } },
    game: { label: 'In a game', game: true, els: [E('who', 'Player and ball'), E('score', 'Score'), E('others', 'Other players')],
      enter() { GAME(); } },
    over: { label: 'Game over', els: [E('go-title', 'Game over'), E('go-winner', 'Winner'), E('go-scores', 'Scores')], classes: ['game-over'],
      enter() {
        text('go-title', P2K.msgText('game_over')); text('go-winner', P2K.msgText('winner', { n: 1 }));
        const box = $('go-scores'); box.innerHTML = '';
        [[1, 2456000], [2, 1130000]].forEach(([n, s]) => { const r = P2K.el('div', 'row'); r.append(P2K.el('span', '', 'PLAYER ' + n), P2K.el('span', '', P2K.num(s))); box.appendChild(r); });
      } },
    splash: { label: 'Big message', game: true, els: [E('splash', 'Message')], probe: { splash: '#splash .msg' },
      enter() { feed({ in_game: true, player: 1, players: { 1: 2456000 } }); const b = $('splash'); b.innerHTML = ''; b.appendChild(P2K.el('div', 'msg', P2K.msgText('ball_saved'))); } },
  };

  const BACK = {
    idle: { label: 'Logo screen (waiting for a game)', els: [E('bg-title', 'Title or logo'), E('bg-best', 'High scores')], classes: ['idle'], enter() { feed({ best: SAMPLE_BEST }); } },
    play: { label: 'While playing', els: [E('bg-who', 'Player and ball'), E('bg-score', 'Score'), E('bg-others', 'Other players')], enter() { GAME(); } },
  };
  const SCENES = glass ? GLASS : BACK;

  // what a scene needs to stay true (a timer in the page may take a class away again)
  function hold() {
    const sc = SCENES[scene]; if (!sc) return;
    if (glass) {
      ['in-game', 'round', 'spin', 'mix', 'picking', 'entering', 'game-over', 'vol', 'quitting', 'demo'].forEach(c => { if (!(sc.classes || []).includes(c) && !(c === 'in-game' && sc.game)) body.classList.remove(c); });
      if (sc.game) body.classList.add('in-game');
      (sc.classes || []).forEach(c => body.classList.add(c));
    } else {
      ['mix', 'spinning', 'demo', 'idle'].forEach(c => { if (!(sc.classes || []).includes(c)) body.classList.remove(c); });
      (sc.classes || []).forEach(c => body.classList.add(c));
      for (const id of ['startPanel', 'statusPanel', 'levelPanel', 'resultPanel']) {
        if (!$(id)) continue;
        const want = !!(sc.panels || {})[id];
        if (id === 'resultPanel') { $(id).hidden = !(want || sc.hide); $(id).classList.toggle('fdj-hide', !want); }
        else if (id === 'statusPanel') { if (!sc.panels || !sc.panels.statusPanel) $(id).hidden = true; }
        else $(id).hidden = !want;
      }
    }
  }
  function enter(name) {
    if (!SCENES[name]) return;
    scene = name; sel = null; group = [];
    if (glass) { $('splash').innerHTML = ''; }
    else { for (const id of ['startPanel', 'levelPanel', 'resultPanel']) if ($(id)) $(id).hidden = true; if ($('resultPanel')) $('resultPanel').classList.remove('fdj-hide'); }
    SCENES[name].enter(); hold(); setTimeout(() => { hold(); draw(); }, 80);
    tell({ fdj: 'select', id: null, vals: null }); draw();
  }

  // ---------------------------------------------------------------- the boxes over the page
  const st = document.createElement('style');
  st.textContent = '#fdj-ed{position:fixed;inset:0;z-index:99999;pointer-events:none}'
    + '#fdj-ed .bx{position:absolute;box-sizing:border-box;border:2px dashed rgba(90,170,255,.9);background:rgba(90,170,255,.08);pointer-events:auto;cursor:move;touch-action:none}'
    + '#fdj-ed .mq{position:absolute;inset:0;pointer-events:auto;cursor:crosshair;touch-action:none}#fdj-ed .mqb{position:absolute;border:1px dashed #2ee6ff;background:rgba(46,230,255,.12);pointer-events:none}'
    + '#fdj-ed .bx.on{border:2px solid #ffc83c;background:rgba(255,200,60,.14)}'
    + '#fdj-ed .bx span{position:absolute;left:0;top:-20px;font:600 13px/18px Arial,sans-serif;background:rgba(0,0,0,.8);color:#fff;padding:0 6px;border-radius:4px;white-space:nowrap}'
    + '#fdj-ed .bx i{position:absolute;right:-9px;bottom:-9px;width:18px;height:18px;border-radius:50%;background:#ffc83c;border:2px solid #000;cursor:nwse-resize;display:none}'
    + '#fdj-ed .bx.on i{display:block}'
    + '#fdj-ed .bx i.hx{right:-9px;bottom:calc(50% - 9px);cursor:ew-resize;border-radius:4px;width:14px;height:22px}'
    + '#fdj-ed .bx i.hy{bottom:-9px;right:calc(50% - 9px);cursor:ns-resize;border-radius:4px;width:22px;height:14px}'
    + '#fdj-ed .bx.part{border-color:rgba(80,230,140,.95);background:rgba(80,230,140,.1)}#fdj-ed .bx.part.on{border-color:#ffc83c;background:rgba(255,200,60,.2)}'
    + '#fdj-ed .gridv{position:absolute;inset:0;background-image:linear-gradient(to right,rgba(255,255,255,.18) 1px,transparent 1px),linear-gradient(to bottom,rgba(255,255,255,.18) 1px,transparent 1px);background-size:10% 10%}'
    + '.fdj-hide{visibility:hidden!important}'
    + (glass ? 'body{background:#08080c!important}' : '');
  document.head.appendChild(st);
  const ov = document.createElement('div'); ov.id = 'fdj-ed'; body.appendChild(ov);

  // the box round what you can see of an element: the union of its text and children, else the element itself
  function boxOf(id) {
    const sc = SCENES[scene], pr = sc && sc.probe && sc.probe[id];
    const e = pr && id.indexOf('>') < 0 ? document.querySelector(pr) : elOf(id); if (!e) return null;
    const rects = [];
    const walk = n => {
      if (n.nodeType === 3) { if (n.textContent.trim()) { const r = document.createRange(); r.selectNodeContents(n); rects.push(r.getBoundingClientRect()); } return; }
      if (n.nodeType !== 1) return;
      const cs = getComputedStyle(n); if (cs.display === 'none' || cs.visibility === 'hidden') return;
      const kids = [...n.childNodes].filter(c => (c.nodeType === 1) || (c.nodeType === 3 && c.textContent.trim()));
      if (!kids.length || /^(CANVAS|IMG|IFRAME|SVG)$/i.test(n.tagName)) { rects.push(n.getBoundingClientRect()); return; }
      const bg = cs.backgroundColor !== 'rgba(0, 0, 0, 0)' || cs.borderTopWidth !== '0px' || cs.backgroundImage !== 'none';
      if (bg) rects.push(n.getBoundingClientRect());
      kids.forEach(walk);
    };
    walk(e);
    let r = rects.filter(q => q.width > 1 && q.height > 1);
    if (!r.length) { const q = e.getBoundingClientRect(); if (q.width < 2 || q.height < 2) return null; r = [q]; }
    const l = Math.min(...r.map(q => q.left)), t = Math.min(...r.map(q => q.top)), rr = Math.max(...r.map(q => q.right)), b = Math.max(...r.map(q => q.bottom));
    return { l, t, w: rr - l, h: b - t };
  }
  const vals = id => { const o = Object.assign({ x: 0, y: 0, s: 1, sx: 1, sy: 1 }, layout[id] || {}); return { x: o.x, y: o.y, s: o.s, sx: o.sx, sy: o.sy }; };
  // the parts inside a piece: its element children that can be seen, as ids like "score>2"
  const partsOf = base => {
    const e = elOf(base); if (!e) return [];
    return [...e.children].map((c, i) => ({ c, id: base + '>' + (i + 1) })).filter(q => { if (q.id.split('>').length > 3) return false; const cs = getComputedStyle(q.c), r = q.c.getBoundingClientRect(); return cs.display !== 'none' && cs.visibility !== 'hidden' && r.width > 1 && r.height > 1; }).slice(0, 40);
  };
  const upOf = id => id && id.indexOf('>') > 0 ? id.slice(0, id.lastIndexOf('>')) : null;
  const partLabel = id => { const e = elOf(id); if (!e) return id; const t = (e.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 18); return id.slice(id.lastIndexOf('>') + 1) + ': ' + (t || e.tagName.toLowerCase()); };
  const scaleOf = id => { const a = id.split('>'); let fx = 1, fy = 1; for (let i = 1; i < a.length; i++) { const o = layout[a.slice(0, i).join('>')] || {}; fx *= (o.s || 1) * (o.sx || 1); fy *= (o.s || 1) * (o.sy || 1); } return { fx, fy }; };
  function showGuides() {                                   // the snap lines of the drag in progress (draw() clears the overlay, so it puts them back)
    ov.querySelectorAll('.sg').forEach(x => x.remove());
    guides.forEach(css => { const g = document.createElement('div'); g.className = 'sg'; g.style.cssText = 'position:absolute;pointer-events:none;background:#2ee6ff;box-shadow:0 0 4px #2ee6ff;' + css; ov.appendChild(g); });
  }
  function draw() {
    const sc = SCENES[scene]; if (!sc) return;
    ov.innerHTML = (showGrid ? '<div class="gridv"></div>' : '') + '<div class="mq"></div>';
    ov.lastChild.onpointerdown = mqStart;
    let list = sc.els.concat(extras.map(x => E(x.id, 'Added: ' + (x.type === 'picture' ? x.src : x.text).slice(0, 40))));
    if (showParts && sel) {                    // the parts inside the picked piece (or, at the end of the line, its brothers and sisters)
      let base = sel, ps = partsOf(base);
      if (!ps.length && upOf(sel)) { base = upOf(sel); ps = partsOf(base); }
      list = list.concat(ps.map(q => ({ id: q.id, label: partLabel(q.id), part: true })));
    }
    for (const el of list) {
      const b = boxOf(el.id); if (!b) continue;
      const d = document.createElement('div'); d.className = 'bx' + (el.part ? ' part' : '') + (sel === el.id || group.indexOf(el.id) >= 0 ? ' on' : ''); d.dataset.id = el.id;
      Object.assign(d.style, { left: b.l + 'px', top: b.t + 'px', width: b.w + 'px', height: b.h + 'px' });
      d.innerHTML = '<span>' + el.label.replace(/</g, '&lt;') + '</span><i></i><i class="hx"></i><i class="hy"></i>';
      d.onpointerdown = ev => begin(ev, el.id, ev.target.tagName === 'I' ? (ev.target.className === 'hx' ? 'x' : ev.target.className === 'hy' ? 'y' : 'u') : '');
      ov.appendChild(d);
    }
    showGuides();
  }
  setInterval(() => { if (!drag && !mq) { hold(); draw(); } }, 400);
  addEventListener('resize', draw);

  // ---------------------------------------------------------------- dragging
  let drag = null;
  const unitPx = () => glass ? (() => { const r = $('stage').getBoundingClientRect(); return { x: r.width / 1280, y: r.height / 1024 }; })() : { x: innerWidth / 100, y: innerHeight / 100 };
  function begin(ev, id, resize) {
    if (!resize && (ev.shiftKey || ev.ctrlKey || ev.metaKey) && id.indexOf('>') < 0) {          // Shift-click adds or removes a piece from the group
      const g = group.length ? group.slice() : (sel ? [sel] : []), at = g.indexOf(id);
      if (at >= 0) g.splice(at, 1); else g.push(id);
      group = g; select(g.indexOf(id) >= 0 ? id : (g[0] || null), true); ev.preventDefault(); return;
    }
    const together = !resize && group.length > 1 && group.indexOf(id) >= 0;
    if (!together) group = [];
    select(id, together);
    const b = boxOf(id), v = vals(id), u0 = unitPx(), f = scaleOf(id), u = { x: u0.x * f.fx, y: u0.y * f.fy };      // inside a scaled piece a part moves by a scaled amount
    drag = { id, resize, others: together ? group.filter(g => g !== id).map(g => ({ id: g, v: vals(g), u: (() => { const f2 = scaleOf(g); return { x: u0.x * f2.fx, y: u0.y * f2.fy }; })() })) : [], x0: ev.clientX, y0: ev.clientY, v, u, cx: b ? b.l + b.w / 2 : 0, cy: b ? b.t + b.h / 2 : 0 };
    drag.d0 = Math.max(10, Math.hypot(ev.clientX - drag.cx, ev.clientY - drag.cy));
    drag.dx0 = Math.max(10, Math.abs(ev.clientX - drag.cx)); drag.dy0 = Math.max(10, Math.abs(ev.clientY - drag.cy));
    try { ev.target.setPointerCapture && ev.target.setPointerCapture(ev.pointerId); } catch (e) {}
    ev.preventDefault();
  }
  addEventListener('pointermove', ev => {
    if (!drag) return;
    const v = Object.assign({}, drag.v);
    if (drag.resize === 'x') v.sx = Math.max(.2, Math.min(5, Math.round(drag.v.sx * Math.abs(ev.clientX - drag.cx) / drag.dx0 * 100) / 100));
    else if (drag.resize === 'y') v.sy = Math.max(.2, Math.min(5, Math.round(drag.v.sy * Math.abs(ev.clientY - drag.cy) / drag.dy0 * 100) / 100));
    else if (drag.resize) v.s = Math.max(.2, Math.min(5, Math.round(drag.v.s * Math.hypot(ev.clientX - drag.cx, ev.clientY - drag.cy) / drag.d0 * 100) / 100));
    else { v.x = Math.round((drag.v.x + (ev.clientX - drag.x0) / drag.u.x) * 10) / 10; v.y = Math.round((drag.v.y + (ev.clientY - drag.y0) / drag.u.y) * 10) / 10; }
    put(drag.id, v, false);
    guides = [];
    if (!drag.resize && snapOn && !ev.altKey) {
      const mine = boxOf(drag.id), SC = SCENES[scene];
      if (mine && SC) {
        const stage = glass ? $('stage').getBoundingClientRect() : { left: 0, top: 0, width: innerWidth, height: innerHeight };
        const xs = [stage.left, stage.left + stage.width / 2, stage.left + stage.width], ys = [stage.top, stage.top + stage.height / 2, stage.top + stage.height];
        for (const el of SC.els.concat(extras.map(x => E(x.id, '')))) { if (el.id === drag.id || group.indexOf(el.id) >= 0) continue; const o = boxOf(el.id); if (o) { xs.push(o.l, o.l + o.w / 2, o.l + o.w); ys.push(o.t, o.t + o.h / 2, o.t + o.h); } }
        const best = (edges, list) => { let r = null; edges.forEach(e => list.forEach(c => { const d = c - e; if (Math.abs(d) <= 8 && (r === null || Math.abs(d) < Math.abs(r.d))) r = { d, at: c }; })); return r; };
        const sx = best([mine.l, mine.l + mine.w / 2, mine.l + mine.w], xs), sy = best([mine.t, mine.t + mine.h / 2, mine.t + mine.h], ys), guide = css => guides.push(css);
        if (sx || sy) {
          if (sx) v.x = Math.round((v.x + sx.d / drag.u.x) * 10) / 10;
          if (sy) v.y = Math.round((v.y + sy.d / drag.u.y) * 10) / 10;
          put(drag.id, v, false);
          if (sx) guide('top:0;bottom:0;width:1px;left:' + sx.at + 'px');
          if (sy) guide('left:0;right:0;height:1px;top:' + sy.at + 'px');
        }
      }
    }
    drag.others.forEach(o => { const w = Object.assign({}, o.v); w.x = Math.round((o.v.x + (v.x - drag.v.x)) * 10) / 10; w.y = Math.round((o.v.y + (v.y - drag.v.y)) * 10) / 10; put(o.id, w, false); });
    showGuides();
    ov.querySelectorAll('.bx').forEach(bx2 => { if (bx2.dataset.id !== drag.id) { const b2 = boxOf(bx2.dataset.id); if (b2) Object.assign(bx2.style, { left: b2.l + 'px', top: b2.t + 'px', width: b2.w + 'px', height: b2.h + 'px' }); } });
    const bx = ov.querySelector('.bx[data-id="' + drag.id + '"]'), b = boxOf(drag.id);
    if (bx && b) Object.assign(bx.style, { left: b.l + 'px', top: b.t + 'px', width: b.w + 'px', height: b.h + 'px' });
  });
  addEventListener('pointerup', () => { if (drag) { drag = null; guides = []; changed(); draw(); } });

  function mqStart(ev) {
    if (ev.target.className !== 'mq' && ev.target.className !== 'gridv') return;
    const sc = SCENES[scene]; if (!sc) return;
    mq = { x0: ev.clientX, y0: ev.clientY, moved: false, base: (ev.shiftKey || ev.ctrlKey) ? (group.length ? group.slice() : (sel ? [sel] : [])) : [], hit: [] };
    mq.ids = sc.els.map(e => e.id).concat(extras.map(x => x.id)); ev.preventDefault();
    try { ev.target.setPointerCapture && ev.target.setPointerCapture(ev.pointerId); } catch (e) {}
  }
  addEventListener('pointermove', ev => {
    if (!mq) return;
    if (Math.abs(ev.clientX - mq.x0) + Math.abs(ev.clientY - mq.y0) > 4) mq.moved = true; if (!mq.moved) return;
    const x1 = Math.min(mq.x0, ev.clientX), x2 = Math.max(mq.x0, ev.clientX), y1 = Math.min(mq.y0, ev.clientY), y2 = Math.max(mq.y0, ev.clientY);
    if (!mq.box) { mq.box = document.createElement('div'); mq.box.className = 'mqb'; ov.appendChild(mq.box); }
    Object.assign(mq.box.style, { left: x1 + 'px', top: y1 + 'px', width: (x2 - x1) + 'px', height: (y2 - y1) + 'px' });
    mq.hit = mq.ids.filter(id => { const b = boxOf(id); return b && b.l + b.w >= x1 && b.l <= x2 && b.t + b.h >= y1 && b.t <= y2; });
    ov.querySelectorAll('.bx').forEach(bx => bx.classList.toggle('on', mq.hit.indexOf(bx.dataset.id) >= 0 || mq.base.indexOf(bx.dataset.id) >= 0));
  });
  addEventListener('pointerup', () => {
    if (!mq) return; const m = mq; mq = null;
    if (m.moved) { const g = m.base.concat(m.hit.filter(x => m.base.indexOf(x) < 0)); group = g; select(g[0] || null, true); }
    else { group = []; select(null); }
    draw();
  });
  function put(id, v, tellParent) {
    layout[id] = Object.assign({}, layout[id], { x: v.x, y: v.y, s: v.s, sx: v.sx === undefined ? 1 : v.sx, sy: v.sy === undefined ? 1 : v.sy });
    if (layout[id].sx === 1) delete layout[id].sx; if (layout[id].sy === 1) delete layout[id].sy;
    if (layout[id].x === 0 && layout[id].y === 0 && layout[id].s === 1 && Object.keys(layout[id]).every(k => ['x', 'y', 's'].includes(k))) delete layout[id];
    apply();
    if (tellParent !== false) changed();
    tell({ fdj: 'select', id: sel, vals: sel ? vals(sel) : null, up: upOf(sel), label: sel && sel.indexOf('>') > 0 ? partLabel(sel) : null });
  }
  function select(id, keep) { sel = id; if (!keep) group = []; tell({ fdj: 'select', id, vals: id ? vals(id) : null, up: upOf(id), label: id && id.indexOf('>') > 0 ? partLabel(id) : null }); draw(); }
  const changed = () => tell({ fdj: 'layout', page, layout });
  const tell = m => { try { parent.postMessage(Object.assign({ page }, m), '*'); } catch (e) {} };

  // ---------------------------------------------------------------- the colours and fonts of the whole game, shown as you change them
  let lastLook = null;
  function look(l) {
    if (!l) return;
    const cfg = P2K.cfg, root = document.documentElement;
    cfg.colors = Object.assign({}, cfg.colors, l.colors || {});
    for (const [k, val] of Object.entries(l.vars || {})) root.style.setProperty('--' + k, val);
    if (!l.vars || !l.vars['bg-image']) root.style.removeProperty('--bg-image');
    cfg.font = undefined;
    P2K.applyLook({ font_files: l.font_files || [], fonts: l.fonts || {}, vars: {} });
    if (glass) P2K.setColors($('stage')); else P2K.setColors(document.documentElement);
    if (!l.fonts || !l.fonts.backglass_display) root.style.removeProperty('--font-display');
    if (!l.fonts || !l.fonts.backglass_body) root.style.removeProperty('--font-body');
    const key = JSON.stringify([l.title, l.logo, l.glass_logo]);
    if (lastLook !== null && key !== lastLook) { cfg.title = l.title || ''; cfg.logo = l.logo; cfg.glass_logo = l.glass_logo; P2K.reconfig(); setTimeout(() => { hold(); draw(); }, 100); }
    lastLook = key;
    setTimeout(draw, 80);
  }

  // ---------------------------------------------------------------- messages and keys
  function key(k, shift) {
    if (!sel) return false;
    const ids = group.length > 1 && group.indexOf(sel) >= 0 ? group : [sel]; let any = false;
    for (const id of ids) if (keyOne(k, shift, id)) any = true;
    if (any) draw(); return any;
  }
  function keyOne(k, shift, id) {
    const v = vals(id), st1 = shift ? 10 : 1, step = glass ? st1 : st1 / 5;
    if (k === 'ArrowLeft') v.x -= step; else if (k === 'ArrowRight') v.x += step;
    else if (k === 'ArrowUp') v.y -= step; else if (k === 'ArrowDown') v.y += step;
    else if (k === '+' || k === '=') v.s = Math.min(5, Math.round((v.s + (shift ? .1 : .02)) * 100) / 100);
    else if (k === '-' || k === '_') v.s = Math.max(.2, Math.round((v.s - (shift ? .1 : .02)) * 100) / 100);
    else if (k === 'Delete' || k === 'Backspace') { v.x = 0; v.y = 0; v.s = 1; v.sx = 1; v.sy = 1; }
    else return false;
    v.x = Math.round(v.x * 10) / 10; v.y = Math.round(v.y * 10) / 10;
    put(id, v); return true;
  }
  addEventListener('keydown', e => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (key(e.key, e.shiftKey)) e.preventDefault();
  }, true);
  addEventListener('message', ev => {
    const m = ev.data || {};
    if (m.fdj === 'scene') enter(m.name);
    else if (m.fdj === 'set') {
      layout = JSON.parse(JSON.stringify(m.layout || {})); extras = JSON.parse(JSON.stringify(m.extras || [])); fontFiles = m.font_files || fontFiles; pages = JSON.parse(JSON.stringify(m.pages || [])); apply();
      setTimeout(draw, 60); if (sel) tell({ fdj: 'select', id: sel, vals: vals(sel) });
    }
    else if (m.fdj === 'look') look(m.look);
    else if (m.fdj === 'force') { P2K.force(m.ids); setTimeout(draw, 80); }
    else if (m.fdj === 'select') select(m.id);   // picking from the tab's list picks just that one
    else if (m.fdj === 'key') key(m.key, !!m.shift);
    else if (m.fdj === 'grid') { showGrid = !!m.on; draw(); }
    else if (m.fdj === 'snap') { snapOn = !!m.on; }
    else if (m.fdj === 'parts') { showParts = !!m.on; draw(); }
  });

  if (false) {          // the real mix page is not needed to place its frame, and it would load all its sounds
    $('mix').removeAttribute('src');
    $('mix').srcdoc = '<body style="margin:0;background:#1a1a30;color:#8a8aa8;font:600 60px sans-serif;display:grid;place-items:center">MULTIBALL MIX</body>';
  }
  apply();
  const list = {}; for (const [k, s] of Object.entries(SCENES)) list[k] = { label: s.label, els: s.els };
  tell({ fdj: 'ready', scenes: list });
  const first = glass ? 'game' : 'idle';
  enter(first);
};
