// core.js: the plumbing shared by index.html (the glass) and backglass.html (the decks).
//
// It loads display.json, listens to p2kdisplay for MPF events, keeps track of
// the game, and calls your handlers. You normally don't need to edit this file.
//
//   P2K.on('light_lock', msg => ...)       any event listed in display.json "events"
//   P2K.on('mode_start', msg => ...)       msg.name is the mode, e.g. 'dj_round'
//   P2K.on('player_variable', msg => ...)  msg.name, msg.value, msg.player_num
//   P2K.on('switch', msg => ...)           msg.name, msg.state (1 pressed, 0 released)
//   P2K.on('*', msg => ...)                everything (msg.event is the name)
//
//   P2K.trigger('dj_hit_a_good')           post an event back to MPF (names must
//                                          start with a prefix in "allow_triggers")
//
// P2K.S holds the game state, P2K.cfg the settings, P2K.live is true when MPF is behind the page.

/* wordart:begin */
// wordart.js: word art and colour effects for text, shared by the portal's editors (backglass and layout), the Pinbox backglass page and a game's own
// display (core.js carries a copy of this file, put there by the portal; edit THIS file and let the portal copy it).
//
//   WA.parts({art, cfx, shape, c})  ->  { decl, anim }   CSS declarations to put on the text, and the animation (if any) as one value
//   WA.style(o)                      ->  an inline style string (declarations and animation together) for a span around the text
//   WA.arts, WA.cfxs, WA.shapes      ->  [[key, label], ...] for the editors' drop-downs
//   WA.kf                            ->  the @keyframes the effects need (add it once to the page)
//
// art    a look given to the letters: outline, hollow, shadows, 3D, neon, chrome, gold, fire, ice, retro, sticker, glitch, emboss
// cfx    a colour effect: a gradient fill, or a colour that moves (cycle, flow, shine, flash, fade)
// shape  a squash, slant, tilt or perspective of the whole word
// c      the second colour (#rrggbb): outline, shadow and glow colour, and the other colour of flash and fade
(function (root) {
  'use strict';
  const clip = '-webkit-text-fill-color:transparent;-webkit-background-clip:text;background-clip:text;text-shadow:none;';
  const grad = g => clip + 'background-image:' + g + ';';
  const steps = (n, dx, dy, col) => { const a = []; for (let i = 1; i <= n; i++) a.push((i * dx).toFixed(3) + 'em ' + (i * dy).toFixed(3) + 'em 0 ' + col); return a.join(','); };
  const ART = {
    outline: ['outline', '-webkit-text-stroke:.07em var(--wc,#000);paint-order:stroke fill;text-shadow:none;'],
    hollow: ['hollow letters', '-webkit-text-fill-color:transparent;-webkit-text-stroke:.05em currentColor;text-shadow:none;'],
    shadow: ['hard shadow', 'text-shadow:.06em .06em 0 var(--wc,#000);'],
    long: ['long shadow', 'text-shadow:' + steps(14, 0.03, 0.03, 'var(--wc,#000)') + ';'],
    extrude: ['3D block', 'text-shadow:' + steps(8, 0.018, 0.018, 'var(--wc,#7a1f00)') + ',.2em .22em .18em rgba(0,0,0,.55);'],
    neon: ['neon tube', 'color:#fff;text-shadow:0 0 .05em #fff,0 0 .16em var(--wc,#ff2bd6),0 0 .35em var(--wc,#ff2bd6),0 0 .7em var(--wc,#ff2bd6);'],
    chrome: ['chrome', grad('linear-gradient(#fff 0%,#e2ecf8 36%,#6b7d93 50%,#c6d5e6 62%,#fff 100%)') + '-webkit-text-stroke:.012em #1c2a3c;filter:drop-shadow(0 .035em .03em #000);'],
    gold: ['gold', grad('linear-gradient(#fff3b0 0%,#ffd23f 35%,#b8860b 52%,#ffe27a 70%,#a8740a 100%)') + '-webkit-text-stroke:.012em #4a3000;filter:drop-shadow(0 .035em .03em #000);'],
    fire: ['fire', grad('linear-gradient(#fff6a0 0%,#ffc21a 30%,#ff6a00 62%,#d10000 100%)') + 'filter:drop-shadow(0 0 .12em #ff5a00) drop-shadow(0 -.04em .1em #ffb000);'],
    ice: ['ice', grad('linear-gradient(#ffffff 0%,#bff4ff 40%,#4fb8ff 100%)') + '-webkit-text-stroke:.01em #0a3a66;filter:drop-shadow(0 0 .12em #52d6ff);'],
    retro: ['retro 80s', grad('linear-gradient(#ffe45e 0%,#ff9d3b 38%,#ff2f8e 52%,#7a2cff 100%)') + 'filter:drop-shadow(.05em .05em 0 var(--wc,#1a0b3c));'],
    sticker: ['sticker', '-webkit-text-stroke:.14em #fff;paint-order:stroke fill;text-shadow:none;filter:drop-shadow(.04em .06em 0 var(--wc,#000));'],
    glitch: ['glitch', 'text-shadow:-.045em 0 #ff1f8f,.045em 0 #17e6ff;'],
    emboss: ['emboss', 'text-shadow:.02em .02em 0 rgba(255,255,255,.75),-.02em -.02em 0 rgba(0,0,0,.7);']
  };
  const CFX = {
    rainbow_g: ['rainbow fill', grad('linear-gradient(90deg,#ff3b3b,#ffb13b,#f6ff3b,#3bff6a,#3bc8ff,#a23bff)')],
    sunset: ['sunset fill', grad('linear-gradient(#ffe259 0%,#ff9a3c 45%,#ff3d6e 75%,#7b2ff7 100%)')],
    ocean: ['ocean fill', grad('linear-gradient(#b8fff2 0%,#35d0e8 45%,#1b5fd1 100%)')],
    candy: ['candy fill', grad('linear-gradient(90deg,#ff6fb5,#ffd1ec,#6fd3ff,#ff6fb5)')],
    toxic: ['toxic fill', grad('linear-gradient(#f4ff6b 0%,#7dff3a 50%,#13a84a 100%)')],
    steel: ['steel fill', grad('linear-gradient(#f4f7fa 0%,#9aa7b5 50%,#56606b 100%)')],
    cycle: ['colour cycle (every colour in turn)', 'wacycle 5s linear infinite'],
    flow: ['rainbow flowing through', clip + 'background-image:linear-gradient(90deg,#ff3b3b,#ffb13b,#f6ff3b,#3bff6a,#3bc8ff,#a23bff,#ff3b3b);background-size:300% 100%;', 'waflow 4s linear infinite'],
    shine: ['shine sweeping across', clip + 'background-image:linear-gradient(100deg,currentColor 0 40%,#fff 50%,currentColor 60% 100%);background-size:260% 100%;', 'washine 2.4s linear infinite'],
    flash2: ['flash between two colours', '', 'waflash .7s step-end infinite'],
    fade2: ['fade between two colours', '', 'wafade 1.6s ease-in-out infinite alternate'],
    fire_f: ['fire flicker', grad('linear-gradient(#fff6a0 0%,#ffc21a 30%,#ff6a00 62%,#d10000 100%)'), 'wafire .5s steps(2) infinite']
  };
  const SHAPE = {
    slant: ['slant right', 'skewX(-14deg)'], back: ['slant left', 'skewX(14deg)'], tall: ['tall and thin', 'scale(.8,1.45)'], wide: ['short and wide', 'scale(1.45,.8)'],
    up: ['tilt up', 'rotate(-6deg)'], down: ['tilt down', 'rotate(6deg)'], persp_l: ['perspective left', 'perspective(18em) rotateY(28deg)'], persp_r: ['perspective right', 'perspective(18em) rotateY(-28deg)'],
    mirror: ['mirror', 'scaleX(-1)'], upside: ['upside down', 'scaleY(-1)']
  };
  const KF = '@keyframes wacycle{from{filter:hue-rotate(0)}to{filter:hue-rotate(360deg)}}' +
    '@keyframes waflow{from{background-position:0 0}to{background-position:300% 0}}' +
    '@keyframes washine{from{background-position:130% 0}to{background-position:-130% 0}}' +
    '@keyframes waflash{0%,49.9%{color:inherit}50%,100%{color:var(--wc,#fff)}}' +
    '@keyframes wafade{from{color:inherit}to{color:var(--wc,#fff)}}' +
    '@keyframes wafire{0%{filter:brightness(1)}50%{filter:brightness(1.3) saturate(1.2)}100%{filter:brightness(.9)}}';
  const has = (t, k) => Object.prototype.hasOwnProperty.call(t, k);
  function parts(o) {
    o = o || {}; let decl = '', anim = '';
    const sh = has(SHAPE, o.shape) ? SHAPE[o.shape][1] : '';
    if (sh) decl += 'display:inline-block;transform:' + sh + ';';
    if (/^#[0-9a-fA-F]{6}$/.test(o.c || '')) decl += '--wc:' + o.c + ';';
    if (has(ART, o.art)) decl += ART[o.art][1];
    if (has(CFX, o.cfx)) { const c = CFX[o.cfx]; if (c.length === 2 && /^[a-z]/.test(c[1]) && !/:/.test(c[1])) anim = c[1]; else { decl += c[1]; if (c[2]) anim = c[2]; } }
    return { decl, anim };
  }
  function style(o) { const p = parts(o); return p.decl + (p.anim ? 'animation:' + p.anim + ';' : ''); }
  const list = t => [['', 'none']].concat(Object.keys(t).map(k => [k, t[k][0]]));
  root.WA = { parts, style, kf: KF, arts: list(ART), cfxs: list(CFX), shapes: list(SHAPE), keys: { art: Object.keys(ART), cfx: Object.keys(CFX), shape: Object.keys(SHAPE) } };
})(typeof window !== 'undefined' ? window : globalThis);
/* wordart:end */
const P2K = (() => {
  const handlers = {};
  const S = {
    in_game: false, players: {}, player: null, modes: [], vars: {},
    last_game: [], best: [], genre_best: {}, mpf: false,
  };
  let cfg = {};

  function on(name, fn) { (handlers[name] = handlers[name] || []).push(fn); }
  function call(name, msg) {
    for (const fn of handlers[name] || []) {
      try { fn(msg); } catch (e) { console.error('handler for', name, e); }
    }
  }

  let lastMsg = Date.now(), lastTrig = Date.now();
  function receive(msg) {
    lastMsg = Date.now();
    if (msg.cmd === 'trigger') lastTrig = lastMsg;
    const name = msg.cmd === 'trigger' ? msg.name : msg.cmd;
    msg.event = name;
    switch (name) {
      case 'state':
        S.in_game = msg.in_game; S.player = msg.player; S.modes = msg.modes || [];
        S.last_game = msg.last_game || []; S.best = msg.best || []; S.genre_best = msg.genre_best || {};
        S.mpf = msg.mpf_connected; S.players = {}; S.vars = {};
        for (const [k, v] of Object.entries(msg.players || {})) S.players[k] = v;
        for (const [k, v] of Object.entries(msg.vars || {})) S.vars[k] = Object.assign({}, v);
        break;
      case 'mpf': S.mpf = msg.connected; if (!msg.connected) { S.in_game = false; S.modes = []; } break;
      case 'game_started': S.in_game = true; break;
      case 'player_added':   // player 1 being added means a new game
        if (msg.player_num === 1) { S.players = {}; S.vars = {}; S.player = null; S.modes = []; }
        S.in_game = true; S.players[msg.player_num] = 0; break;
      case 'player_turn_start': S.player = msg.player_num; break;
      case 'player_variable': {
        const p = msg.player_num || S.player || 1;
        (S.vars[p] = S.vars[p] || {})[msg.name] = msg.value;
        if (msg.name === 'score') S.players[p] = Number(msg.value) || 0;
        break;
      }
      case 'mode_start': if (!S.modes.includes(msg.name)) S.modes.push(msg.name); break;
      case 'mode_stop': S.modes = S.modes.filter(m => m !== msg.name); break;
      case 'best': S.best = msg.best || []; if (msg.genre_best) S.genre_best = msg.genre_best; break;
      case 'scoreboard': S.last_game = msg.scores; S.best = msg.best; S.genre_best = msg.genre_best || S.genre_best; break;
      case 'game_ended': S.in_game = false; break;
      case 'reset': S.in_game = false; S.modes = []; break;
    }
    call(name, msg);
    call('*', msg);
  }

  // the current player's variable, e.g. v('lock_shots')
  const v = (name, fallback = 0) => ((S.vars[S.player || 1] || {})[name] ?? fallback);

  function trigger(name) {
    if (!P2K.live || P2K.mute) return Promise.resolve();   // mute: the attract demo must not reach MPF
    return fetch('/trigger?name=' + encodeURIComponent(name), { method: 'POST' })
      .catch(e => console.warn('trigger', name, e));
  }

  // ------------------------------------------------------------ helpers
  const fmt = (text, vals) => String(text || '').replace(/\{(\w+)\}/g, (m, k) => (k in vals ? vals[k] : m));
  const num = n => Number(n || 0).toLocaleString('en-GB');
  const msgText = (key, vals) => fmt((cfg.messages || {})[key] || key, vals || {});
  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  };
  function setColors(root) {
    for (const [k, val] of Object.entries(cfg.colors || {})) root.style.setProperty('--' + k, val);
    if (cfg.font) root.style.setProperty('--font', cfg.font);
  }

  // The look: fonts, sizes and colours from display.json "look" (see CUSTOMISING_LOOK.md).
  //   font_files  [{family, file, weight?}]  font files to load (put them in display/assets/fonts)
  //   fonts       {glass, backglass_display, backglass_body}  font stacks to use
  //   vars        {name: value}  any CSS variable, written without the leading --
  function applyLook(look) {
    const root = document.documentElement;
    for (const f of look.font_files || []) {
      try {
        const face = new FontFace(f.family, 'url(' + f.file + ')', { weight: String(f.weight || 'normal') });
        face.load().then(x => document.fonts.add(x)).catch(e => console.warn('font', f.file, e));
      } catch (e) { console.warn('font', f.file, e); }
    }
    const fo = look.fonts || {};
    if (fo.glass) cfg.font = fo.glass;     // the glass reads it back in setColors
    if (fo.backglass_display) root.style.setProperty('--font-display', fo.backglass_display);
    if (fo.backglass_body) root.style.setProperty('--font-body', fo.backglass_body);
    for (const [k, val] of Object.entries(look.vars || {})) root.style.setProperty('--' + k, val);
  }

  // The layout: where the pieces of each screen sit, how big they are and how they look, from display/layout.json (made by the
  // Layout tab of the status site):
  //   "glass" / "backglass": { "score": {"x": 0, "y": 20, "s": 1.1, "hide": true, "color": "#ff0", "ff": "'My Font', sans-serif"} }
  //   "extras": { "glass": [ {"id": "fx1", "type": "text", "text": "DJ NIGHT", "when": "attract"} ], "backglass": [...] }   pieces you added
  //   "font_files": [ {"family": "My Font", "file": "assets/custom/My.ttf"} ]
  // x and y move the element (pixels of the 1280 x 1024 glass stage, or percent of the width and height of the backglass screen),
  // s scales it. Done with the CSS translate and scale properties, so the page's own transforms and animations are not touched.
  // The multiball mix frame (backglass.html?view=glass) takes no layout.
  const qs = new URLSearchParams(location.search);
  const EDIT = qs.get('edit') === '1';
  const PAGE = /backglass/.test(location.pathname) ? (qs.get('view') === 'glass' ? 'mix' : 'backglass') : 'glass';
  const LAYOUT_ID = /^[A-Za-z][\w-]*(>\d{1,2}){0,2}$/;       // a piece, or a part inside it: "score>2" is the second thing inside the score, "best>1>3" a part of that
  const partSel = id => { const a = id.split('>'); return '#' + a[0] + a.slice(1).map(n => '>:nth-child(' + n + ')').join(''); };
  const loadedFonts = new Set();
  const FDJ_LOOP = {"slow": ["blink", "1s", "step-end"], "fast": ["blink", ".4s", "step-end"], "pulse": ["pulse", "1.6s", "ease-in-out"], "flicker": ["flicker", "3s", "linear"], "glow": ["glow", "2s", "ease-in-out"], "breathe": ["breathe", "3s", "ease-in-out"], "heartbeat": ["heart", "1.4s", "ease-in-out"], "shake": ["shake", ".35s", "linear"], "wobble": ["wobble", "1.2s", "ease-in-out"], "swing": ["swing", "2s", "ease-in-out"], "float": ["float", "3s", "ease-in-out"], "bounce": ["bounce", "1.2s", "ease-out"], "rainbow": ["rainbow", "4s", "linear"]};
  const FDJ_ENTER = {"fade": ["fade", ".9s", "ease-out"], "slide_up": ["up", ".8s", "ease-out"], "slide_down": ["down", ".8s", "ease-out"], "slide_left": ["left", ".8s", "ease-out"], "slide_right": ["right", ".8s", "ease-out"], "zoom": ["zoom", ".7s", "cubic-bezier(.2,1.4,.4,1)"], "drop": ["drop", "1s", "ease-in"], "spin": ["spin", ".9s", "ease-out"], "flip": ["flip", ".8s", "ease-out"], "wipe": ["wipe", ".9s", "ease-out"]};
  const FDJ_KF = "@keyframes fdjfl-blink{0%{opacity:1}50%{opacity:0}100%{opacity:1}}@keyframes fdjfl-pulse{0%,100%{opacity:1}50%{opacity:.15}}\n@keyframes fdjfl-flicker{0%,19%,22%,62%,64%,100%{opacity:1}20%,21%,63%{opacity:.25}}\n@keyframes fdjfl-glow{0%,100%{text-shadow:0 0 .1em currentColor,0 0 .25em #000}50%{text-shadow:0 0 .35em currentColor,0 0 .8em currentColor}}\n@keyframes fdjfl-breathe{0%,100%{transform:scale(1)}50%{transform:scale(1.12)}}\n@keyframes fdjfl-heart{0%,40%,100%{transform:scale(1)}10%{transform:scale(1.15)}20%{transform:scale(1)}30%{transform:scale(1.1)}}\n@keyframes fdjfl-shake{0%,100%{transform:translate(0,0)}20%{transform:translate(-.06em,.03em)}40%{transform:translate(.06em,-.03em)}60%{transform:translate(-.05em,-.04em)}80%{transform:translate(.05em,.04em)}}\n@keyframes fdjfl-wobble{0%,100%{transform:rotate(-3deg)}50%{transform:rotate(3deg)}}\n@keyframes fdjfl-swing{0%,100%{transform:rotate(-8deg)}50%{transform:rotate(8deg)}}\n@keyframes fdjfl-float{0%,100%{transform:translateY(-.12em)}50%{transform:translateY(.12em)}}\n@keyframes fdjfl-bounce{0%,100%{transform:translateY(0)}30%{transform:translateY(-.3em)}50%{transform:translateY(0)}65%{transform:translateY(-.1em)}80%{transform:translateY(0)}}\n@keyframes fdjfl-rainbow{0%{color:#ff3b3b}17%{color:#ffb13b}33%{color:#f6ff3b}50%{color:#3bff6a}67%{color:#3bc8ff}83%{color:#a23bff}100%{color:#ff3b3b}}\n@keyframes fdjen-fade{from{opacity:0}to{opacity:1}}\n@keyframes fdjen-up{from{opacity:0;transform:translateY(1em)}to{opacity:1;transform:none}}\n@keyframes fdjen-down{from{opacity:0;transform:translateY(-1em)}to{opacity:1;transform:none}}\n@keyframes fdjen-left{from{opacity:0;transform:translateX(-2em)}to{opacity:1;transform:none}}\n@keyframes fdjen-right{from{opacity:0;transform:translateX(2em)}to{opacity:1;transform:none}}\n@keyframes fdjen-zoom{from{opacity:0;transform:scale(.2)}to{opacity:1;transform:none}}\n@keyframes fdjen-drop{0%{opacity:0;transform:translateY(-2em)}55%{opacity:1;transform:translateY(0)}70%{transform:translateY(-.4em)}85%{transform:translateY(0)}92%{transform:translateY(-.12em)}100%{transform:none}}\n@keyframes fdjen-spin{from{opacity:0;transform:rotate(-360deg) scale(.2)}to{opacity:1;transform:none}}\n@keyframes fdjen-flip{from{opacity:0;transform:perspective(20em) rotateX(90deg)}to{opacity:1;transform:perspective(20em) rotateX(0)}}\n@keyframes fdjen-wipe{from{clip-path:inset(0 100% 0 0)}to{clip-path:inset(0 -1em 0 0)}}";
  function layoutCss(map) {
    const ux = PAGE === 'glass' ? 'px' : 'vw', uy = PAGE === 'glass' ? 'px' : 'vh';
    let anyFl = false;
    const out = Object.entries(map || {}).filter(([id]) => LAYOUT_ID.test(id)).map(([id, o]) => {
      o = o || {};
      const x = Number(o.x) || 0, y = Number(o.y) || 0, s = Number(o.s) || 1, sx = Number(o.sx) || 1, sy = Number(o.sy) || 1, q = partSel(id), all = q + ',' + q + ' *';
      const sc = sx === 1 && sy === 1 ? s : (Math.round(s * sx * 1000) / 1000) + ' ' + (Math.round(s * sy * 1000) / 1000);
      let css = q + '{translate:' + x + ux + ' ' + y + uy + ';scale:' + sc + (o.hide ? (EDIT ? ';opacity:.25' : ';visibility:hidden') : '') + '}';
      if (/^#[0-9a-fA-F]{6}$/.test(o.color || '')) css += '\n' + all + '{color:' + o.color + ' !important}';
      if (typeof o.ff === 'string' && o.ff && !/[;{}<>]/.test(o.ff)) css += '\n' + all + '{font-family:' + o.ff + ' !important}';
      if (/^(left|center|right)$/.test(o.ta || '')) css += '\n' + all + '{text-align:' + o.ta + ' !important}';
      if (o.fw === 'b' || o.fw === 'n') css += '\n' + all + '{font-weight:' + (o.fw === 'b' ? 800 : 400) + ' !important}';
      if (o.fi) css += '\n' + all + '{font-style:italic !important}';
      if (o.tt === 'upper' || o.tt === 'lower') css += '\n' + all + '{text-transform:' + (o.tt === 'upper' ? 'uppercase' : 'lowercase') + ' !important}';
      if (Number.isFinite(Number(o.ls)) && Number(o.ls) !== 0 && o.ls !== '') css += '\n' + all + '{letter-spacing:' + Math.max(-20, Math.min(60, Number(o.ls))) + 'px !important}';
      const has = (t, k) => Object.prototype.hasOwnProperty.call(t, k), lp = has(FDJ_LOOP, o.fl) ? FDJ_LOOP[o.fl] : null, en = has(FDJ_ENTER, o.en) ? FDJ_ENTER[o.en] : null;
      const wp = typeof WA !== 'undefined' ? WA.parts({ art: o.wa, cfx: o.wf, shape: o.ws, c: o.wc }) : { decl: '', anim: '' };        // word art, colour effect and shape (wordart.js)
      if (wp.decl) css += '\n' + q + '{' + wp.decl.replace(/;/g, ' !important;') + '}' + (/background-clip/.test(wp.decl) ? '\n' + q + ' *{background-image:inherit !important;-webkit-background-clip:inherit !important;background-clip:inherit !important;-webkit-text-fill-color:inherit !important;text-shadow:none !important}' : '');
      if (lp || en || wp.anim) {
        anyFl = true;
        const list = [];
        if (en) list.push('fdjen-' + en[0] + ' ' + en[1] + ' ' + en[2] + ' both');
        if (wp.anim) list.push(wp.anim);
        if (lp) list.push('fdjfl-' + lp[0] + ' ' + lp[1] + ' ' + lp[2] + ' ' + (en ? en[1] : '0s') + ' infinite');
        css += '\n' + q + '{animation:' + list.join(',') + (lp && lp[0] === 'swing' ? ';transform-origin:50% 0' : '') + '}';
      }
      return css;
    }).join('\n');
    return out + (anyFl ? '\n' + FDJ_KF + (typeof WA !== 'undefined' ? WA.kf : '') : '');
  }
  // an inline thing (a span in a line of text) ignores translate and scale; make the moved ones inline-block
  function fixInline(map) {
    for (const id of Object.keys(map || {})) {
      if (id.indexOf('>') < 0 || !LAYOUT_ID.test(id)) continue;
      let e; try { e = document.querySelector(partSel(id)); } catch (x) { continue; }
      if (e && getComputedStyle(e).display === 'inline') e.style.display = 'inline-block';
    }
  }
  const EXTRA_CSS = {
    glass: '.fdj-x{position:absolute;left:0;top:0;white-space:nowrap;font-size:80px;line-height:1.1;color:var(--text,#fff);z-index:5;letter-spacing:4px}'
      + '.fdj-x img{display:block;width:300px;height:auto}'
      + 'body.in-game .fdj-x[data-when=attract],body.game-over .fdj-x[data-when=attract],body:not(.in-game) .fdj-x[data-when=game]{display:none}',
    backglass: '.fdj-x{position:fixed;left:0;top:0;white-space:nowrap;font:400 6vh var(--font-display);line-height:1.1;color:var(--chrome,#fff);z-index:30;letter-spacing:.3vh}'
      + '.fdj-x img{display:block;width:25vw;height:auto}'
      + 'body:not(.idle) .fdj-x[data-when=idle],body.idle .fdj-x[data-when=play]{display:none}',
  };
  // Pages: named groups of added pieces with a rule for when they show (display/layout.json "pages"):
  //   {"id": "pg1", "name": "Multiball banner", "bg": "#000000", "rule": {"screens": ["game"], "modes": ["dj_mix"], "balls": [1, 2], "players": [1], "min_score": 1000000}}
  // Every list that is given must match (any one of its values); a list that is left out means any. The screens are, on the glass:
  // attract game over pick entry lookup mix spin; on the backglass: idle play mix spinning. A piece with no page is always there.
  // Added text can hold live values written in braces, like {score}, {ball} or {p2}.
  let PAGES = [], FORCE = [];
  const sampleVals = { score: 2456000, player: 1, ball: 2, mult: 3, lock: 2, need: 3, balls: 1, jackmult: 3, p1: 2456000, p2: 1130000, p3: 0, p4: 0, best: 8450000, bestname: 'DJX', title: 'FLIPPING DJS' };
  function liveVal(k) {
    const nm = n => (n === undefined || n === null || n === '' ? '' : num(n));
    let r;
    switch (k) {
      case 'score': r = S.in_game ? nm(S.players[S.player]) : ''; break;
      case 'player': r = S.in_game ? S.player || '' : ''; break;
      case 'ball': r = S.in_game ? v('ball', '') : ''; break;
      case 'mult': r = S.in_game ? v('top_mult', 1) : ''; break;
      case 'lock': r = S.in_game ? v('lock_shots', 0) : ''; break;
      case 'need': r = cfg.lock_shots || 3; break;
      case 'balls': r = S.in_game ? v('dj_balls', 0) : ''; break;
      case 'jackmult': r = S.in_game ? v('mix_mult', 1) : ''; break;
      case 'p1': case 'p2': case 'p3': case 'p4': r = S.in_game ? nm(S.players[k.slice(1)]) : ''; break;
      case 'best': r = S.best && S.best[0] ? nm(S.best[0].score) : ''; break;
      case 'bestname': r = S.best && S.best[0] ? S.best[0].name || '' : ''; break;
      case 'title': r = cfg.title || ''; break;
      case 'time': return new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
      default: return '{' + k + '}';
    }
    if (EDIT && (r === '' || r === undefined) && k in sampleVals) r = typeof sampleVals[k] === 'number' && sampleVals[k] > 9999 ? num(sampleVals[k]) : sampleVals[k];
    return String(r === undefined || r === null ? '' : r);
  }
  const fillText = s => String(s || '').replace(/\{(\w+)\}/g, (m, k) => liveVal(k));
  function screenIs(name) {
    const b = document.body.classList;
    if (PAGE === 'glass') {
      switch (name) {
        case 'attract': return !b.contains('in-game') && !b.contains('game-over') && !b.contains('entering') && !b.contains('picking');
        case 'game': return b.contains('in-game') && !b.contains('round') && !b.contains('picking');
        case 'over': return b.contains('game-over'); case 'pick': return b.contains('picking'); case 'entry': return b.contains('entering');
        case 'lookup': return b.contains('round'); case 'mix': return b.contains('mix'); case 'spin': return b.contains('spin');
      }
      return false;
    }
    switch (name) {
      case 'idle': return b.contains('idle'); case 'play': return !b.contains('idle'); case 'mix': return b.contains('mix'); case 'spinning': return b.contains('spinning');
    }
    return false;
  }
  function ruleOn(r) {
    r = r || {};
    if ((r.screens || []).length && !r.screens.some(screenIs)) return false;
    if ((r.modes || []).length && !r.modes.some(m => S.modes.includes(m))) return false;
    if ((r.balls || []).length && !r.balls.includes(Number(v('ball', 1)))) return false;
    if ((r.players || []).length && !r.players.includes(Number(S.player || 0))) return false;
    if (r.min_score && !(Number(S.players[S.player]) >= r.min_score)) return false;
    return true;
  }
  function tick() {
    for (const p of PAGES) {
      const d = document.getElementById(p.id); if (!d) continue;
      const on = FORCE === 'all' || (Array.isArray(FORCE) && FORCE.includes(p.id)) || ruleOn(p.rule);
      const want = on ? '' : 'none'; if (d.style.display !== want) d.style.display = want;
    }
    document.querySelectorAll('.fdj-x[data-text]').forEach(d => { const s = fillText(d.dataset.text); if (d.textContent !== s) d.textContent = s; });
  }
  setInterval(() => { if (PAGE !== 'mix' && (PAGES.length || document.querySelector('.fdj-x[data-text]'))) tick(); }, 250);
  function setExtras(list, fontFiles, pages) {
    for (const f of fontFiles || []) {                       // fonts a piece uses that the look does not already load
      if (!f || !f.family || !f.file || loadedFonts.has(f.family)) continue;
      loadedFonts.add(f.family);
      try { new FontFace(f.family, 'url(' + f.file + ')').load().then(x => document.fonts.add(x)).catch(e => console.warn('font', f.file, e)); } catch (e) { /* skip */ }
    }
    document.querySelectorAll('.fdj-x, .fdj-pg').forEach(n => n.remove());
    const host = PAGE === 'glass' ? document.getElementById('stage') : document.body;
    if (!host) return;
    PAGES = (pages || []).filter(p => p && /^pg\d+$/.test(p.id || ''));
    for (const p of PAGES) {
      const d = document.createElement('div'); d.id = p.id; d.className = 'fdj-pg';
      d.style.cssText = 'position:' + (PAGE === 'glass' ? 'absolute' : 'fixed') + ';inset:0;pointer-events:none;z-index:' + (PAGE === 'glass' ? 4 : 29) + (/^#[0-9a-fA-F]{6}$/.test(p.bg || '') ? ';background:' + p.bg : '');
      host.appendChild(d);
    }
    for (const e of list || []) {
      if (!e || !/^fx\d+$/.test(e.id || '')) continue;
      const d = document.createElement('div'); d.id = e.id; d.className = 'fdj-x'; d.dataset.when = e.when || 'always';
      if (e.type === 'picture' && /^[\w .()-]+$/.test(e.src || '')) { const im = document.createElement('img'); im.alt = ''; im.src = 'assets/custom/' + encodeURIComponent(e.src); d.appendChild(im); }
      else { d.dataset.text = String(e.text || ''); d.textContent = fillText(e.text); }
      (e.pg && document.getElementById(e.pg) || host).appendChild(d);
    }
    tick();
  }

  function setLayout(map, extras, fontFiles, pages) {
    let st = document.getElementById('fdj-layout');
    if (!st) { st = document.createElement('style'); st.id = 'fdj-layout'; document.head.appendChild(st); }
    st.textContent = (PAGE === 'mix' ? '' : EXTRA_CSS[PAGE] + '\n') + layoutCss(map);
    fixInline(map);
    if (extras !== undefined) setExtras(extras, fontFiles, pages);
  }

  // ------------------------------------------------------------ connection
  let es = null;
  function connect() {
    if (es) es.close();
    es = new EventSource('/events');
    es.onmessage = e => receive(JSON.parse(e.data));
    es.onerror = () => { S.mpf = false; call('mpf', { cmd: 'mpf', event: 'mpf', connected: false }); };
  }
  // A stream that has gone quiet in the middle of a game (events normally arrive many times a second) is opened again;
  // the server sends the whole state first, so the page catches up. quiet() says how long it has been silent, in seconds.
  const quiet = () => Math.round((Date.now() - lastMsg) / 1000);
  // In a game the page also sends dj_ping to MPF every 10 seconds, and MPF sends it straight back (display.json lists it under events), so a stream
  // that is open but no longer delivers anything (the cabinet's backglass once sat deaf for minutes, missing the start of a mini game) is told apart
  // from a quiet moment: after 20 seconds without a message the stream is opened again, and if that does not help within another 20 seconds the
  // page reloads itself (at most once every two minutes).
  let reopenedAt = 0;
  const pingOn = () => P2K.live && !P2K.mute && S.in_game && ((cfg.events || []).indexOf('dj_ping') >= 0);
  setInterval(() => { if (pingOn()) P2K.trigger('dj_ping'); }, 10000);
  setInterval(() => {
    if (!P2K.live || !S.in_game) { reopenedAt = 0; return; }
    const silent = Date.now() - lastMsg;
    if (!pingOn()) { if (silent > 30000) { lastMsg = Date.now(); connect(); } return; }          // no ping to test with: the old rule
    if (Date.now() - lastTrig < 20000) { reopenedAt = 0; return; }       // a state snapshot after a reopen does not count: only real events (the ping echo) do
    if (!reopenedAt) { reopenedAt = Date.now(); connect(); return; }
    if (Date.now() - reopenedAt > 20000) {
      let last = 0; try { last = Number(sessionStorage.getItem('fdj_reload_at') || 0); } catch (e) {}
      if (Date.now() - last < 120000) { reopenedAt = Date.now(); connect(); return; }
      try { sessionStorage.setItem('fdj_reload_at', String(Date.now())); } catch (e) {}
      P2K.trigger('dj_err_stream_reload_' + PAGE);
      setTimeout(() => location.reload(), 300);
    }
  }, 5000);

  // On the machine p2kdisplay serves /config and live events. Under any other
  // web server, read display.json directly and run without a game.
  // sound.json is written by the Sound tab of the status site: the levels (music, voice, mini games, multiball mix, effects) and the on/off switches
  async function loadSound() {
    try {
      const sj = await (await fetch('sound.json', { cache: 'no-store' })).json();
      cfg.sound = (sj && typeof sj === 'object' && !Array.isArray(sj)) ? sj : {};
    } catch (e) { cfg.sound = cfg.sound || {}; }          // no sound.json: every level as display.json has it
    call('sound', cfg.sound);
  }
  async function start() {
    try {
      if (EDIT) throw new Error('edit mode reads display.json');          // the Layout tab of the status site serves these pages
      cfg = await (await fetch('/config', { cache: 'no-store' })).json();
      P2K.live = true;
    } catch (e) {
      try { cfg = await (await fetch('display.json', { cache: 'no-store' })).json(); }
      catch (e2) { console.warn('no display.json, using defaults', e2); }
    }
    // look.json is written by the Customise tab of the status site and wins over display.json
    try {
      const lk = await (await fetch('look.json', { cache: 'no-store' })).json();
      if (lk && typeof lk === 'object' && !Array.isArray(lk)) {
        if (lk.title) cfg.title = lk.title;
        if (lk.logo) cfg.logo = lk.logo;
        if (lk.glass_logo) cfg.glass_logo = lk.glass_logo;
        cfg.colors = Object.assign({}, cfg.colors, lk.colors || {});
        const a = cfg.look || {}, b = lk.look || {};
        cfg.look = { font_files: (a.font_files || []).concat(b.font_files || []), fonts: Object.assign({}, a.fonts, b.fonts), vars: Object.assign({}, a.vars, b.vars) };
      }
    } catch (e) { /* no look.json: the standard look */ }
    // layout.json: see setLayout above
    let lay = {};
    if (PAGE !== 'mix') {
      try { lay = await (await fetch('layout.json', { cache: 'no-store' })).json(); setLayout((lay && lay[PAGE]) || {}, ((lay && lay.extras) || {})[PAGE] || [], lay && lay.font_files, ((lay && lay.pages) || {})[PAGE] || []); }
      catch (e) { /* no layout.json: every piece where the stylesheet puts it */ }
    }
    if (EDIT) {                      // the layout editor: the page looks like the cabinet but takes no events and sends nothing
      P2K.live = true; P2K.mute = true;
      cfg.demo = Object.assign({}, cfg.demo, { enabled: false });
    }
    await loadSound();
    P2K.cfg = cfg;
    applyLook(cfg.look || {});
    call('config', cfg);
    if (EDIT) {
      const s = document.createElement('script'); s.src = 'edit.js';
      s.onload = () => P2K.editor && P2K.editor(PAGE, lay && lay[PAGE], ((lay && lay.extras) || {})[PAGE] || [], lay && lay.font_files, ((lay && lay.pages) || {})[PAGE] || []);
      document.head.appendChild(s);
    } else if (P2K.live) connect();
  }

  document.addEventListener('keydown', e => { if (e.key.toLowerCase() === 'r' && !e.repeat) location.reload(); });

  return { on, receive, start, trigger, quiet, loadSound, S, v, cfg, live: false, mute: false, fmt, num, msgText, el, setColors, setLayout, applyLook, force: f => { FORCE = f; tick(); }, reconfig: () => call('config', cfg), page: PAGE, edit: EDIT };
})();
