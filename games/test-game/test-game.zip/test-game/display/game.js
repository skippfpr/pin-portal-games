// game.js: the glass of the template game. Attract screen with the high scores, the player, ball and score in a game,
// big messages (splash) and game over. Keys: C calibration grid, F next flip setting, R reload.
// Add your own pieces: put an element with an id in index.html, style it in style.css, fill it in render() below,
// and list it in the scenes of edit.js so the Layout tab can move it.

const $ = id => document.getElementById(id);
const { S, el, num, msgText, v } = P2K;
const body = document.body, stage = $('stage');
let cfg = {}, W = 1280, H = 1024, flip = 'none';
const FLIPS = ['none', 'horizontal', 'vertical', 'both'];

function fit() {
  const s = Math.min(innerWidth / W, innerHeight / H);
  const fx = flip === 'horizontal' || flip === 'both' ? -1 : 1, fy = flip === 'vertical' || flip === 'both' ? -1 : 1;
  stage.style.transform = `scale(${s * fx}, ${s * fy})`;
}
addEventListener('resize', fit);

P2K.on('config', c => {
  cfg = c; W = c.width || 1280; H = c.height || 1024;
  Object.assign(stage.style, { width: W + 'px', height: H + 'px', margin: `${-H / 2}px 0 0 ${-W / 2}px` });
  flip = new URLSearchParams(location.search).get('flip') || c.flip || 'none';
  P2K.setColors(stage);
  if (c.glass_logo) {                      // a logo picture instead of the title text (Customise tab)
    const im = document.createElement('img');
    im.src = c.glass_logo; im.alt = c.title || ''; im.style.cssText = 'display:block;max-width:1000px;max-height:340px;object-fit:contain';
    im.onerror = () => { $('title').textContent = c.title || ''; };
    $('title').textContent = ''; $('title').appendChild(im);
  } else $('title').textContent = c.title || '';
  fit(); buildGrid(); attract(); render();
});

// ------------------------------------------------------------ drawing the HUD
function render() {
  body.classList.toggle('in-game', !!S.in_game);
  $('status').textContent = S.mpf ? '' : msgText('waiting');
  if (!S.in_game) return;
  const p = S.player || 1;
  $('who').textContent = msgText('player', { n: p }) + '   ' + msgText('ball', { n: v('ball', 1) });
  $('score').textContent = num(S.players[p]);
  const others = Object.keys(S.players).map(Number).filter(n => n !== p).sort();
  $('others').innerHTML = '';
  for (const n of others) { const d = el('div'); d.append(el('b', '', 'P' + n), document.createTextNode(num(S.players[n]))); $('others').appendChild(d); }
}

function splash(text, color) {
  const box = $('splash');
  box.innerHTML = '';
  const m = el('div', 'msg', text);
  if (color) m.style.color = color;
  m.addEventListener('animationend', () => m.remove());
  box.appendChild(m);
}

// ------------------------------------------------------------ events
for (const ev of ['state', 'mpf', 'player_added', 'player_turn_start', 'mode_start', 'mode_stop', 'game_started', 'ball_start'])
  P2K.on(ev, render);

P2K.on('game_started', () => body.classList.remove('game-over'));
P2K.on('player_variable', m => {
  render();
  if (m.name === 'score' && m.player_num === S.player) { const s = $('score'); s.classList.remove('bump'); void s.offsetWidth; s.classList.add('bump'); }
});
P2K.on('ball_save_start_save_saving_ball', () => splash(msgText('ball_saved'), 'var(--good)'));
P2K.on('tilt_warning', () => splash(msgText('tilt_warning'), 'var(--warn)'));
P2K.on('tilt', () => splash(msgText('tilt'), 'var(--warn)'));

// ------------------------------------------------------------ attract
let lineTimer = null;
function attract() {
  const b = $('best'); b.innerHTML = '';
  if (S.best.length) {
    b.appendChild(el('div', 'head', msgText('best')));
    S.best.slice(0, 5).forEach((s, i) => { const r = el('div', 'row'); r.append(el('span', '', (i + 1) + '.'), el('span', '', s.name || '---'), el('span', '', num(s.score))); b.appendChild(r); });
  }
  const lines = cfg.attract_lines || [];
  let i = 0;
  clearInterval(lineTimer);
  const next = () => { $('attract-line').textContent = lines.length ? lines[i++ % lines.length] : ''; };
  next(); lineTimer = setInterval(next, 2500);
}
P2K.on('best', attract);
P2K.on('state', () => { if (!S.in_game) attract(); });
P2K.on('scoreboard', attract);

// ------------------------------------------------------------ game over
P2K.on('game_ended', () => {
  const sc = Object.entries(S.players).map(([n, s]) => [Number(n), Number(s) || 0]).sort((a, b) => b[1] - a[1]);
  if (!sc.length) return;
  $('go-title').textContent = msgText('game_over');
  $('go-winner').textContent = sc.length > 1 && sc[0][1] === sc[1][1] ? msgText('tie') : msgText('winner', { n: sc[0][0] });
  const box = $('go-scores'); box.innerHTML = '';
  sc.forEach(([n, s]) => { const r = el('div', 'row'); r.append(el('span', '', msgText('player', { n })), el('span', '', num(s))); box.appendChild(r); });
  body.classList.add('game-over');
  setTimeout(() => { body.classList.remove('game-over'); attract(); render(); }, 8000);
});

// ------------------------------------------------------------ calibration grid
function buildGrid() {
  const g = $('grid'); g.innerHTML = '';
  for (let x = 0; x <= W; x += 64) { const l = el('div', 'line'); Object.assign(l.style, { left: x + 'px', top: 0, width: (x % 320 ? 1 : 3) + 'px', height: H + 'px' }); g.appendChild(l); }
  for (let y = 0; y <= H; y += 64) { const l = el('div', 'line'); Object.assign(l.style, { top: y + 'px', left: 0, height: (y % 256 ? 1 : 3) + 'px', width: W + 'px' }); g.appendChild(l); }
  const corner = (t, css) => { const c = el('div', 'corner', t); Object.assign(c.style, css); g.appendChild(c); };
  corner('TOP LEFT', { left: '20px', top: '14px' }); corner('TOP RIGHT', { right: '20px', top: '14px' });
  corner('BOTTOM LEFT', { left: '20px', bottom: '14px' }); corner('BOTTOM RIGHT', { right: '20px', bottom: '14px' });
}
document.addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  if (k === 'c') body.classList.toggle('grid');
  if (k === 'f') { flip = FLIPS[(FLIPS.indexOf(flip) + 1) % FLIPS.length]; fit(); }
});

// ------------------------------------------------------------ the Calibrate tab of the panel
// It sends ui_calib_on / _off, _pos_N_X_Y (spot N moved) and _flip_MODE to the glass: the numbered spots of display.json record_slots
// and the grid are shown, so you can read off positions on the real glass. The template does not use the spots in a game.
function spots(on) {
  const box = $('records'); box.innerHTML = '';
  body.classList.toggle('grid', on);
  if (!on) return;
  (cfg.record_slots || []).forEach((s, i) => { const d = el('div', 'rec', String(i + 1)); d.dataset.n = i + 1; d.style.left = s.x + 'px'; d.style.top = s.y + 'px'; box.appendChild(d); });
}
P2K.on('*', m => {
  const a = String(m && (m.event || m.name) || '').split('_');
  if (a[0] !== 'ui' || a[1] !== 'calib') return;
  if (a[2] === 'on') spots(true);
  else if (a[2] === 'off') spots(false);
  else if (a[2] === 'pos') { const d = document.querySelector('#records .rec[data-n="' + Number(a[3]) + '"]'); if (d) { d.style.left = Number(a[4]) + 'px'; d.style.top = Number(a[5]) + 'px'; } }
  else if (a[2] === 'flip' && FLIPS.indexOf(a[3]) >= 0) { flip = a[3]; fit(); }
});

// ------------------------------------------------------------ moving target (modes/sweep)
// The helpers the block below needs: the five spots of display.json record_slots, and a countdown.
const recCount = () => (cfg.record_slots || []).length || 5;
const recSlot = n => ((cfg.record_slots || [])[n - 1]) || { x: 100 + n * 100, y: 500 };
let rareTimer = null, rareEl = null;
function rareClear() { clearInterval(rareTimer); rareTimer = null; if (rareEl) { rareEl.remove(); rareEl = null; } }
function clockStart(secs, x, y) {
  rareClear(); let left = Number(secs);
  rareEl = el('div', 'swclock', String(left)); rareEl.style.left = x + 'px'; rareEl.style.top = y + 'px';
  $('records').appendChild(rareEl);
  rareTimer = setInterval(() => { left = Math.max(0, left - 1); if (rareEl) rareEl.textContent = String(left); }, 1000);
}
// moving target (modes/sweep): a record glides back and forth over the five spots and the player hits the shot under it as it passes.
// The page knows where the record is, so it judges each hit (sweep_N_hit from the game) and sends dj_sweep_perfect, dj_sweep_good or
// dj_sweep_miss back for the score. Test it without the game: press M on the glass (during a game it starts the real thing instead),
// then keys 1 to 5 stand in for the five shots. Numbers (speed, window, scores) are "sweep" in display.json.
let sw = null;
const swSavedDelay = () => { try { const v = localStorage.getItem('sweep_delay_ms'); return v === null ? null : Number(v); } catch (e) { return null; } };
const swCfg = () => { const c = Object.assign({ seconds: 40, speed: 0.9, faster: 1.06, max_speed: 2.0, perfect: 0.3, window: 0.55, delay_ms: 0, repeat_ms: 600, look: 'target', shots: [3], from: 1, to: 5, path: null, unit_px: 200, size: 280, image: '', perfect_score: 50000, good_score: 25000 }, cfg.sweep || {}); const d = swSavedDelay(); if (d !== null && !isNaN(d)) c.delay_ms = d; return c; };
function swXY(p) {
  if (sw && sw.path) {                                                  // a drawn path: p is in spots (unit_px each) along it
    const P_ = sw.path, t = Math.max(0, Math.min(P_.len, p * sw.unit));
    let i = 1; while (i < P_.cum.length - 1 && P_.cum[i] < t) i++;
    const a = P_.pts[i - 1], b = P_.pts[i], l = (P_.cum[i] - P_.cum[i - 1]) || 1, f = (t - P_.cum[i - 1]) / l;
    return { x: a[0] + (b[0] - a[0]) * f, y: a[1] + (b[1] - a[1]) * f };
  }
  const n = recCount(), i = Math.max(0, Math.min(n - 1, Math.floor(p))), j = Math.min(n - 1, i + 1), f = p - i;
  const a = recSlot(i + 1), b = recSlot(j + 1);
  return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f };
}
function swPathMake(c) {                                                // the path of display.json (sweep, path) as points and running lengths, or null
  const pts = (c.path || []).filter(q => Array.isArray(q) && q.length === 2).map(q => [Number(q[0]), Number(q[1])]).filter(q => isFinite(q[0]) && isFinite(q[1]));
  if (pts.length < 2) return null;
  const cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  return cum[cum.length - 1] > 1 ? { pts, cum, len: cum[cum.length - 1] } : null;
}
function swProject(P_, x, y) {                                          // how far along the path the point nearest (x, y) is, in pixels
  let best = 1e18, at = 0;
  for (let i = 1; i < P_.pts.length; i++) {
    const a = P_.pts[i - 1], b = P_.pts[i], dx = b[0] - a[0], dy = b[1] - a[1], l2 = dx * dx + dy * dy || 1;
    const f = Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / l2)), px = a[0] + dx * f, py = a[1] + dy * f, d = Math.hypot(x - px, y - py);
    if (d < best) { best = d; at = P_.cum[i - 1] + Math.sqrt(l2) * f; }
  }
  return at;
}
// a video target: the glass plays a clip and the target is wherever the track (traced on the Targets tab) says it is at that moment of the clip
function swTrackPos(tr, t) {
  const n = tr.length; if (!n) return { x: 0, y: 0 };
  if (t <= tr[0][0]) return { x: tr[0][1], y: tr[0][2] }; if (t >= tr[n - 1][0]) return { x: tr[n - 1][1], y: tr[n - 1][2] };
  let lo = 0, hi = n - 1; while (hi - lo > 1) { const m = (lo + hi) >> 1; if (tr[m][0] <= t) lo = m; else hi = m; }
  const a = tr[lo], b = tr[hi], f = (t - a[0]) / ((b[0] - a[0]) || 1);
  return { x: a[1] + (b[1] - a[1]) * f, y: a[2] + (b[2] - a[2]) * f };
}
function swFrame(now) {
  if (!sw) return;
  if (sw.vid) { const c0 = swTrackPos(sw.track, sw.vid.currentTime); sw.el.style.transform = 'translate3d(' + c0.x + 'px,' + c0.y + 'px,0)'; sw.raf = requestAnimationFrame(swFrame); return; }
  const dt = Math.min(0.1, (now - sw.last) / 1000); sw.last = now;
  const lo = sw.lo, hi = sw.hi;
  sw.p += sw.dir * sw.speed * dt;
  if (sw.p > hi) { sw.p = 2 * hi - sw.p; sw.dir = -1; } else if (sw.p < lo) { sw.p = 2 * lo - sw.p; sw.dir = 1; }
  const c = swXY(sw.p); sw.el.style.transform = 'translate3d(' + c.x + 'px,' + c.y + 'px,0)';
  sw.raf = requestAnimationFrame(swFrame);
}
function swStart(local) {
  swStop(true); if (typeof nd !== 'undefined' && nd) ndStop(true);
  const c = swCfg(), box = $('records');
  const spots = [], n = recCount(), path = swPathMake(c), size = Math.max(60, Math.min(600, +c.size || 280));
  for (let i = 1; i <= n; i++) { if (c.shots.indexOf(i) < 0) { spots.push(null); continue; } const s = recSlot(i), d = el('div', 'swspot'); d.style.left = s.x + 'px'; d.style.top = s.y + 'px'; d.style.width = d.style.height = Math.round(size * 0.68) + 'px'; d.style.margin = '-' + Math.round(size * 0.34) + 'px 0 0 -' + Math.round(size * 0.34) + 'px'; box.appendChild(d); spots.push(d); }
  const vcfg = c.video && c.video.file && Array.isArray(c.video.track) && c.video.track.length >= 2 ? c.video : null;
  let vid = null;
  if (vcfg) { vid = document.createElement('video'); vid.muted = true; vid.loop = true; vid.playsInline = true; vid.src = 'video/' + encodeURIComponent(vcfg.file); vid.style.cssText = 'position:absolute;left:0;top:0;width:' + W + 'px;height:' + H + 'px;object-fit:cover;background:#000'; box.insertBefore(vid, box.firstChild); vid.play().catch(() => {}); }
  const d = el('div', 'swrec' + (c.image ? ' img' : c.look === 'target' ? ' target' : ''));
  if (vid && !vcfg.draw) d.style.display = 'none';
  d.style.width = d.style.height = size + 'px'; d.style.margin = '-' + (size / 2) + 'px 0 0 -' + (size / 2) + 'px';
  if (c.image) { d.style.backgroundImage = 'url("' + String(c.image).replace(/"/g, '') + '")'; }
  box.appendChild(d);
  const unit = Math.max(40, +c.unit_px || 200), spotP = {};
  c.shots.forEach(k => { spotP[k] = path ? swProject(path, recSlot(k).x, recSlot(k).y) / unit : k - 1; });
  sw = { path, unit, spotP, p: path ? 0 : Math.max(0, c.from - 1), lo: path ? 0 : Math.max(0, c.from - 1), hi: path ? path.len / unit : Math.min(n - 1, c.to - 1), vid, track: vcfg ? vcfg.track : null, size, dir: 1, speed: c.speed, last: performance.now(), el: d, spots, local: !!local, score: 0, hits: 0, lastHit: {}, cal: [], calMs: null };
  document.body.classList.add('mode-sweep');
  splash(msgText('sweep_start'), 'var(--accent)');
  clockStart(c.seconds, W / 2, 250);
  if (local) sw.end = setTimeout(() => swStop(), c.seconds * 1000);
  sw.raf = requestAnimationFrame(swFrame);
}
function swStop(quiet) {
  if (!sw) return;
  cancelAnimationFrame(sw.raf); clearTimeout(sw.end);
  sw.el.remove(); if (sw.vid) { sw.vid.pause(); sw.vid.remove(); } sw.spots.forEach(d => d && d.remove()); { const l = $('swcal'); if (l) l.remove(); }
  const was = sw; sw = null;
  document.body.classList.remove('mode-sweep'); rareClear();
  if (was.local && !quiet) splash(msgText('sweep_end', { v: num(was.score) }), 'var(--good)');
}
function swHit(n) {
  if (!sw) return;
  const c = swCfg();
  if (c.shots.indexOf(n) < 0) return;                                  // only the shots the mode uses
  let p, dist, vpx = null;
  if (sw.vid) {                                                          // video target: how far the traced target was from this shot's spot, in pixels (bullseye inside a quarter of the size, near miss inside half)
    const tp = swTrackPos(sw.track, Math.max(0, sw.vid.currentTime - (sw.local ? 0 : c.delay_ms) * sw.vid.playbackRate / 1000)), sl = recSlot(n);
    vpx = Math.hypot(tp.x - sl.x, tp.y - sl.y); dist = vpx; p = 0;
  } else {
    p = sw.p - sw.dir * sw.speed * (sw.local ? 0 : c.delay_ms) / 1000;               // where the record was when the ball arrived
    dist = Math.abs(p - sw.spotP[n]);
  }
  const now = performance.now();
  if (sw.lastHit[n] && now - sw.lastHit[n] < c.repeat_ms) return;         // a ball bouncing over the same shot counts once
  sw.lastHit[n] = now;
  const off = vpx !== null ? Math.round(vpx) + ' px' : (sw.dir * (p - sw.spotP[n]) < 0 ? 'early ' : 'late ') + Math.round(dist / sw.speed * 100) * 10 + ' ms';   // the record had not reached the spot yet, or had gone past it
  const tier = vpx !== null ? (vpx <= sw.size * 0.25 ? 'perfect' : vpx <= sw.size * 0.5 ? 'good' : 'miss') : dist <= c.perfect ? 'perfect' : dist <= c.window ? 'good' : 'miss';
  const spot = sw.spots[n - 1]; if (spot) { spot.classList.remove('perfect', 'good', 'miss'); void spot.offsetWidth; spot.classList.add(tier); }
  const pts = tier === 'perfect' ? c.perfect_score : tier === 'good' ? c.good_score : 0;
  splash(msgText('sweep_' + tier, { v: num(pts), w: off }), tier === 'perfect' ? 'var(--good)' : tier === 'good' ? 'var(--accent)' : 'var(--warn)');
  if (tier !== 'miss') { sw.speed = Math.min(c.max_speed, sw.speed * c.faster); sw.hits++; if (sw.vid) sw.vid.playbackRate = Math.max(0.25, Math.min(4, sw.speed / (c.speed || 1))); }
  if (sw.local) {
    sw.score += pts;
    // calibration: how late (+) or early (-) each press was against the record, with no delay applied; the average is the delay to use
    const ms = sw.vid ? 9999 : sw.dir * (sw.p - sw.spotP[n]) / sw.speed * 1000;
    if (Math.abs(ms) < 500) { sw.cal.push(ms); sw.calMs = Math.round(sw.cal.reduce((a, b) => a + b, 0) / sw.cal.length / 10) * 10; }
    if (sw.cal.length >= 3) { const l = $('swcal') || el('div'); l.id = 'swcal'; l.textContent = 'Average ' + (sw.calMs >= 0 ? 'late ' : 'early ') + Math.abs(sw.calMs) + ' ms over ' + sw.cal.length + ' presses. Enter keeps ' + sw.calMs + ' as the delay, Backspace clears it.'; $('records').appendChild(l); }
  } else P2K.trigger('dj_sweep_' + tier);
}
for (let n = 1; n <= 9; n++) P2K.on('sweep_' + n + '_hit', () => { if (sw && !sw.local) swHit(n); });
P2K.on('sweep_start', () => swStart(false));
// the Targets tab of the portal runs the local test and reloads the glass through these (ui_ events never reach MPF)
P2K.on('ui_targets_sweep', () => { if (S.in_game) return; if (sw) swStop(); else swStart(true); });
P2K.on('ui_targets_stop', () => { if (sw) swStop(true); if (typeof nd !== 'undefined' && nd) ndStop(true); if (typeof rtTest !== 'undefined' && rtTest) { clearTimeout(rtTest); rtTest = null; ndOff(5); rareClear(); } });
P2K.on('ui_targets_reload', () => location.reload());
P2K.on('sweep_over', () => swStop(true));
document.addEventListener('keydown', e => {
  if (e.repeat || e.ctrlKey || e.altKey || e.metaKey) return;
  const k = e.key.toLowerCase();
  if (k === 'm') {
    if (sw) { swStop(); return; }                                         // M again ends a test
    if (S.in_game && S.mpf) P2K.trigger('dj_sweep_go'); else swStart(true);
  }
  if (sw && sw.local && k >= '1' && k <= '9') swHit(Number(k));
  if (sw && sw.local && e.key === ' ') { swHit(swCfg().shots.reduce((b, n) => Math.abs(sw.spotP[n] - sw.p) < Math.abs(sw.spotP[b] - sw.p) ? n : b)); e.preventDefault(); }       // space: whichever spot the record is nearest
  if (sw && sw.local && e.key === 'Enter' && sw.calMs !== null) { try { localStorage.setItem('sweep_delay_ms', String(Math.max(0, sw.calMs))); } catch (x) {} splash('DELAY SAVED  ' + Math.max(0, sw.calMs) + ' ms', 'var(--good)'); }
  if (sw && sw.local && e.key === 'Backspace') { try { localStorage.removeItem('sweep_delay_ms'); } catch (x) {} splash('DELAY CLEARED', 'var(--warn)'); }
});

// ------------------------------------------------------------ targets (modes/targets)
// One static bullseye at a time on the five spots: spot_on_N shows it (it grows while it comes up), targets_groove turns it
// green, spot_got_N is a hit and spot_off_N takes it away. Test without the game: press N outside a game, keys 1 to 5 are the shots;
// during a game N starts the real one (dj_targets_go).
const ndEls = {};
function ndOn(n) {
  ndOff(n);
  const s = recSlot(n), d = el('div', 'ndtarget'), c = cfg.targets || {}, sz = Math.max(60, Math.min(600, +c.size || 240)); d.style.left = s.x + 'px'; d.style.top = s.y + 'px';
  d.style.width = d.style.height = sz + 'px'; d.style.margin = '-' + (sz / 2) + 'px 0 0 -' + (sz / 2) + 'px';
  if (c.image) { d.classList.add('img'); d.style.backgroundImage = 'url("' + String(c.image).replace(/"/g, '') + '")'; }
  d.style.setProperty('--arm', ((cfg.targets || {}).arm_seconds || 3) + 's');
  $('records').appendChild(d); ndEls[n] = d;
}
function ndOff(n) { const d = ndEls[n]; if (d) { delete ndEls[n]; d.remove(); } }
function ndGot(n) { const d = ndEls[n]; if (!d) return; delete ndEls[n]; d.classList.add('got'); setTimeout(() => d.remove(), 500); }
function ndClear() { Object.keys(ndEls).forEach(n => ndOff(n)); rareClear(); }
for (let n = 1; n <= 9; n++) {
  P2K.on('spot_on_' + n, () => ndOn(n));
  P2K.on('spot_got_' + n, () => ndGot(n));
  P2K.on('spot_off_' + n, () => ndOff(n));
}
const ndCfg = () => Object.assign({ seconds: 45, arm_seconds: 3, groove_seconds: 2, groove_score: 50000, plain_score: 25000 }, cfg.targets || {});
P2K.on('targets_start', () => { splash(msgText('targets_start'), 'var(--accent)'); clockStart(ndCfg().seconds, W / 2, 250); });
P2K.on('targets_groove', () => Object.values(ndEls).forEach(d => d.classList.add('groove')));
P2K.on('targets_perfect_hit', () => splash(msgText('targets_perfect', { v: num(ndCfg().groove_score) }), 'var(--good)'));
P2K.on('targets_over', ndClear);
P2K.on('mode_stop', m => { if (m.name === 'targets') ndClear(); });
// random target (modes/random_target): the dice put a bullseye on spot 5 (the drop target) with a clock. spot_on_5, spot_got_5 and spot_off_5 draw it above.
const rtCfg = () => Object.assign({ seconds: 30, score: 100000 }, cfg.random || {});
P2K.on('random_start', () => { splash(msgText('random_start'), 'var(--accent)'); clockStart(rtCfg().seconds, W / 2, 250); });
P2K.on('random_got', () => splash(msgText('random_got', { v: num(rtCfg().score) }), 'var(--good)'));
P2K.on('random_over', () => rareClear());
let rtTest = null;                                                  // the Targets tab's test button: the same look, run in the page when no game is on
P2K.on('ui_targets_random', () => {
  if (S.in_game) return;
  if (rtTest) { clearTimeout(rtTest); rtTest = null; ndOff(5); rareClear(); return; }
  ndOn(5); splash(msgText('random_start'), 'var(--accent)'); clockStart(rtCfg().seconds, W / 2, 250);
  rtTest = setTimeout(() => { rtTest = null; ndOff(5); rareClear(); }, rtCfg().seconds * 1000);
});
// the local test: the same timeline as the mode, run in the page
let nd = null;
P2K.on('ui_targets_targets', () => { if (S.in_game) return; if (nd) { ndStop(); return; } ndLocalStart(); });
function ndLocalStart() {
  if (typeof sw !== 'undefined' && sw) swStop(true);
  nd = { score: 0, last: 0, on: 0, groove: false };
  splash(msgText('targets_start'), 'var(--accent)'); clockStart(ndCfg().seconds, W / 2, 250);
  nd.end = setTimeout(() => ndStop(), ndCfg().seconds * 1000); ndNext();
}
function ndStop(quiet) {
  if (!nd) return;
  clearTimeout(nd.t); clearTimeout(nd.end); ndClear();
  const was = nd; nd = null;
  if (!quiet) splash(msgText('targets_end', { v: num(was.score) }), 'var(--good)');
}
function ndNext() {
  if (!nd) return;
  const c = ndCfg(); let n; do { n = 1 + Math.floor(Math.random() * recCount()); } while (n === nd.last && recCount() > 1);
  nd.last = n; nd.on = n; nd.groove = false; ndOn(n);
  nd.t = setTimeout(() => {
    if (!nd) return; nd.groove = true; if (ndEls[n]) ndEls[n].classList.add('groove');
    nd.t = setTimeout(() => { if (!nd) return; ndOff(n); nd.on = 0; nd.t = setTimeout(ndNext, 1000); }, c.groove_seconds * 1000);
  }, c.arm_seconds * 1000);
}
function ndHit(n) {
  if (!nd || nd.on !== n) return;
  const c = ndCfg(), pts = nd.groove ? c.groove_score : c.plain_score;
  nd.score += pts; clearTimeout(nd.t); nd.on = 0; ndGot(n);
  splash(nd.groove ? msgText('targets_perfect', { v: num(pts) }) : '+' + num(pts), nd.groove ? 'var(--good)' : 'var(--accent)');
  nd.t = setTimeout(ndNext, 1000);
}
document.addEventListener('keydown', e => {
  if (e.repeat || e.ctrlKey || e.altKey || e.metaKey) return;
  const k = e.key.toLowerCase();
  if (k === 't') {
    if (nd) { ndStop(); return; }
    if (S.in_game && S.mpf) { P2K.trigger('dj_targets_go'); return; }
    ndLocalStart();
  }
  if (nd && k >= '1' && k <= '9') ndHit(Number(k));
});

// ------------------------------------------------------------ quitting from attract
let quitTimer = null;
P2K.on('quit_hold_start', m => {
  let n = Number(m.seconds) || 5;
  $('quit-text').textContent = msgText('quit_hold');
  const tick = () => { $('quit-count').textContent = n > 0 ? n : ''; n--; };
  clearInterval(quitTimer); tick(); quitTimer = setInterval(tick, 1000);
  body.classList.add('quitting');
});
P2K.on('quit_hold_cancel', () => { clearInterval(quitTimer); body.classList.remove('quitting'); });
P2K.on('quit_now', () => { clearInterval(quitTimer); $('quit-text').textContent = msgText('quit_now'); $('quit-count').textContent = ''; body.classList.add('quitting'); });

P2K.on('mode_stop', m => { if (m.name === 'sweep') swStop(true); });

P2K.start();
